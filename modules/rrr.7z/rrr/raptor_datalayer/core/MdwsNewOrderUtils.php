<?php namespace raptor;

require_once 'StringUtils.php';

class MdwsNewOrderUtils {

    public static  function getImagingTypes($mdwsDao) {
        //$result = array();
        //$result['37'] = 'ANGIO/NEURO/INTERVENTIONAL';
        //$result['5'] = 'MRI';
        //return $result;
        
        $soapResult = $mdwsDao->makeQuery('getImagingOrderTypes', array());
     
        if (isset($soapResult->getImagingOrderTypesResult->fault)) {
            throw new \Exception($soapResult->getImagingOrderTypesResult->fault->message);
        }
        
        $result = array();
        if (!isset($soapResult->getImagingOrderTypesResult->OrderTypeTO) ||
                count($soapResult->getImagingOrderTypesResult->OrderTypeTO) == 0) {
            //Just return the empty array.
            return $result;
        }
        $imagingTypes = $soapResult->getImagingOrderTypesResult->OrderTypeTO;
        $typeCount = count($soapResult->getImagingOrderTypesResult->OrderTypeTO);
        
        for ($i = 0; $i < $typeCount; $i++) 
        {
            $id = $soapResult->getImagingOrderTypesResult->OrderTypeTO[$i]->id;
            $name = $soapResult->getImagingOrderTypesResult->OrderTypeTO[$i]->name1;
            $result[$id] = $name;
        }
        
        return $result;
    }
    
    /**
     * This call returns the ENTIRE list of orderable items for an imaging ID type.
     * The call to getRadiologyOrderDialog's shortList and commonProcedures are a SUBSET of the results.
     */
    public static function getOrderableItems($mdwsDao, $imagingTypeId) {
//        $orderableItems = array();
//        $orderableItems['2771'] = array('name' => 'CT - HEAD (1 VIEW)', 'requiresApproval' => false);
//        $orderableItems['2852'] = array('name' => 'CT - CHEST (LATERAL)', 'requiresApproval' => false);
//        
//        return $orderableItems;
        
        $soapResult = $mdwsDao->makeQuery('getOrderableItems', array('dialogId' => $imagingTypeId));
        
        if (isset($soapResult->getOrderableItemsResult->fault)) {
            throw new \Exception($soapResult->getOrderableItemsResult->fault->message);
        }
        
        $result = array();
        if (!isset($soapResult->getOrderableItemsResult->OrderTypeTO) ||
                count($soapResult->getOrderableItemsResult->OrderTypeTO) == 0) {
            //Just return the empty array.
            return $result;
        }
        
        $orderableItems = $soapResult->getOrderableItemsResult->OrderTypeTO;
        $typeCount = count($soapResult->getOrderableItemsResult->OrderTypeTO);
        
        for ($i = 0; $i < $typeCount; $i++) 
        {
            $id = $orderableItems[$i]->id;
            $name = $orderableItems[$i]->name1;
            $requiresApproval = $orderableItems[$i]->requiresApproval;
            $result[$id] = array('name'=>$name, 'requiresApproval'=>$requiresApproval);
        }
        
        return $result;
    }
    
    public static function getRadiologyOrderDialog($mdwsDao, $imagingTypeId, $patientId) {
//        $result = array();
//        
//        $categories = array();
//        $categories['O'] = 'OUTPATIENT';
//        $categories['I'] = 'INPATIENT';
//        $result['categories'] = $categories;
//        
//        // same structure (key/value pairs)
//        $modifiers = array();
//        $result['modifiers'] = $modifiers;
//        
//        // same structure (key/value pairs)
//        $urgencies = array();
//        $result['urgencies'] = $urgencies;
//        
//        // same structure (key/value pairs)
//        $transports = array();
//        $result['tranports'] = $transports;
//        
//        // same structure (key/value pairs)
//        $submitTo = array();
//        $result['submitTo'] = $submitTo;
//        
//        $commonProcedures = array();
//        $commonProcedures['2771'] = array('name' => 'CT - HEAD (1 VIEW)', 'shortName' => 'CT', 'requiresApproval' => false);
//        $commonProcedures['2852'] = array('name' => 'CT - CHEST (LATERAL)', 'shortName' => 'CT CHEST', 'requiresApproval' => false);
//        $result['commonProcedures'] = $commonProcedures;
//        
//        $shortList = array();
//        $shortList['2771'] = array('name' => 'CT - HEAD (1 VIEW)', 'shortName' => 'CT', 'requiresApproval' => false);
//        $shortList['2852'] = array('name' => 'CT - CHEST (LATERAL)', 'shortName' => 'CT CHEST', 'requiresApproval' => false);
//        $result['shortList'] = $shortList;
//        
//        $last7DaysExams = array();
//        $last7DaysExams['TODO'] = array('UNSURE OF STRUCTURE' => 'TODO!!');
//        $result['last7DaysExams'] = $last7DaysExams;
//        
//        return $result;
        
        
        $soapResult = $mdwsDao->makeQuery('getRadiologyOrderDialog', array('patientId'=>$patientId, 'dialogId' => $imagingTypeId));
        
        if (isset($soapResult->getRadiologyOrderDialogResult->fault)) {
            throw new \Exception($soapResult->getRadiologyOrderDialogResult->fault->message);
        }
        
        $result = array();
        
        $dialog = $soapResult->getRadiologyOrderDialogResult;
        
        $result['categories'] = MdwsNewOrderUtils::getKeyValuePairsFromTaggedTextArray($dialog->categories);
        $result['modifiers'] = MdwsNewOrderUtils::getKeyValuePairsFromTaggedTextArray($dialog->modifiers);
        $result['urgencies'] = MdwsNewOrderUtils::getKeyValuePairsFromTaggedTextArray($dialog->urgencies);
        $result['transports'] = MdwsNewOrderUtils::getKeyValuePairsFromTaggedTextArray($dialog->transports);
        $result['submitTo'] = MdwsNewOrderUtils::getKeyValuePairsFromTaggedTextArray($dialog->submitTo);
        
        // common procedures for dialog
        $result['commonProcedures'] = array();
        if (isset($dialog->commonProcedures) 
                && isset($dialog->commonProcedures->ClinicalProcedureTO)
                && count($dialog->commonProcedures->ClinicalProcedureTO) > 0) {
            $commonProcs = array();
            $commonProcCount = count($dialog->commonProcedures->ClinicalProcedureTO);
            for ($i = 0; $i < $commonProcCount; $i++) {
                $procId = $dialog->commonProcedures->ClinicalProcedureTO[$i]->id;
                $procName = $dialog->commonProcedures->ClinicalProcedureTO[$i]->name;
                $commonProcs[$procId] = $procName;
            }
            $result['commonProcedures'] = $commonProcs;
        }
        
        // short list of procedures for dialog
        $result['shortList'] = array();
        if (isset($dialog->shortList) 
                && isset($dialog->shortList->ClinicalProcedureTO)
                && count($dialog->shortList->ClinicalProcedureTO) > 0) {
            $shortList = array();
            $shortListCount = count($dialog->shortList->ClinicalProcedureTO);
            for ($i = 0; $i < $shortListCount; $i++) {
                $procId = $dialog->shortList->ClinicalProcedureTO[$i]->id;
                $procName = $dialog->shortList->ClinicalProcedureTO[$i]->name;
                $shortList[$procId] = $procName;
            }
            $result['shortList'] = $shortList;
        }

        // last 7 days of exams for patient
        $result['last7DaysExams'] = array();
        if (isset($dialog->lastSevenDaysExams) 
                && isset($dialog->lastSevenDaysExams->ImagingExamTO)
                && count($dialog->lastSevenDaysExams->ImagingExamTO) > 0) {
            $exams = array();
            $examsCount = count($dialog->lastSevenDaysExams->ImagingExamTO);
            for ($i = 0; $i < $examsCount; $i++) {
                $examId = $dialog->lastSevenDaysExams->ImagingExamTO[$i]->id;
                $examName = $dialog->lastSevenDaysExams->ImagingExamTO[$i]->name;
                $exams[$procId] = $examName;
            }
            $result['last7DaysExams'] = $exams;
        }
        
        return $result;
    }

    public static function getKeyValuePairsFromTaggedTextArray($taggedTextArray) {
        $count = 0;
        if (isset($taggedTextArray)
                && isset($taggedTextArray->results) 
                && isset($taggedTextArray->results->TaggedText) 
                && count($taggedTextArray->results->TaggedText) > 0) {
            $count = count($taggedTextArray->results->TaggedText);
        }
        $result = array();
        for ($i = 0; $i < $count; $i++) 
        {
            $id = $taggedTextArray->results->TaggedText[$i]->tag;
            $name = $taggedTextArray->results->TaggedText[$i]->text;
            $result[$id] = $name;
        }
        return $result;
    }

    public static function createNewRadiologyOrder($mdwsDao, $orderChecks, $args) {
        $patientId = $args['patientId'];
        $duz = $mdwsDao->getDUZ();
        $locationIEN = $args['locationIEN'];
        $dlgDisplayGroupId = $args['imagingTypeId'];
        $orderableItemIen = $args['orderableItemId'];
        $urgencyCode = $args['urgencyCode'];
        $modeCode = $args['modeCode'];
        $classCode = $args['classCode'];
        $submitTo = $args['submitTo'];
        $pregnant = $args['pregnant'];
        $isolation = $args['isolation'];
        $reasonForStudy = $args['reasonForStudy'];
        $clinicalHx = \raptor\StringUtils::joinStrings($args['clinicalHx'], '|'); // 'Line 1|followed by 2|and three';
        $startDateTime = \raptor\StringUtils::convertPhpDateTimeToISO($args['startDateTime']);
        $preOpDateTime = \raptor\StringUtils::convertPhpDateTimeToISO($args['preOpDateTime']);
        $modifierIds = \raptor\StringUtils::joinStrings($args['modifierIds'], '|');
        $eSig = $args['eSig'];

        $soapResult = $mdwsDao->makeQuery('saveNewRadiologyOrder', array(
            'patientId'=>$patientId,
            'duz'=>$duz,
            'locationIEN'=>$locationIEN,
            'dlgDisplayGroupId'=>$dlgDisplayGroupId,
            'orderableItemIen'=>$orderableItemIen,
            'urgencyCode'=>$urgencyCode,
            'modeCode'=>$modeCode,
            'classCode'=>$classCode,
            'submitTo'=>$submitTo,
            'pregnant'=>$pregnant,
            'isolation'=>$isolation,
            'reasonForStudy'=>$reasonForStudy,
            'clinicalHx'=>$clinicalHx,
            'startDateTime'=>$startDateTime,
            'preOpDateTime'=>$preOpDateTime,
            'modifierIds'=>$modifierIds,
            'eSig'=>$eSig          
        ));
            
        $soapResult = $soapResult->saveNewRadiologyOrderResult;
        if (isset($soapResult->fault)) {
            throw new \Exception('There was a problem creating the order: '.$soapResult->fault->message);
        }
        // TODO - need to verify isset()
        $order = array();
        $order['id'] = $soapResult->id;
        $order['timestamp'] = $soapResult->timestamp;
        $order['startDate'] = $soapResult->startDate;
        $order['status'] = $soapResult->status;
        $order['sigStatus'] = $soapResult->sigStatus;
        $order['text'] = $soapResult->text;
        $order['detail'] = $soapResult->detail;
        // find most recent 75.1 record corresponding to this new order ID
        $order['radiologyOrderId'] = MdwsNewOrderUtils::getRadiologyOrderIenFromOrderId($mdwsDao, $orderIen);
        return $order;
    }
    
    // NOTE: ONLY USE THIS CALL FOR NEWLY CREATED ORDERS!!! THE QUERY MAY TIMEOUT 
    // IN PRODUCTION OTHERWISE AND CAUSE A LARGE VISTA LOAD RESULTING IN OI&T's WRATH!!!
    // 
    // Searches the rad/nuc med orders (75.1) file for order ID from file 100 
    public static  function getRadiologyOrderIenFromOrderId($mdwsDao, $orderId) {
        //$orderId = '34436;1';
        $semiColonIdx = strpos($orderId, ';');
        if ($semiColonIdx) {
            $orderId = substr($orderId, 0, $semiColonIdx);
        }
                
        $result = $mdwsDao->makeQuery("ddrLister", array(
            'file'=>'75.1', 
            'iens'=>'',   
            'fields'=>'.01;7', 
            'flags'=>'IPB',      
            'maxrex'=>'1',   
            'from'=>'',      
            'part'=>'',        
            'xref'=>'#',        
            'screen'=> 'I ($P(^(0),U,7)='.$orderId.')', 
            'identifier'=>''
        ));
        
        if (!isset($result) || !isset($result->ddrListerResult)
                || isset($result->ddrListerResult->fault) 
                || !isset($result->ddrListerResult->text)) {
            throw new \Exception('Error when attempting to locate radiology order IEN by Order file IEN: '.print_r($result));
        }
        
        $result = $result->ddrListerResult->text->string;
        // double check field 7 matches order IEN
        $resultPieces = explode('^', $result);
        $radFileOrderIen = $resultPieces[2];    
        if ($radFileOrderIen != $orderId) {
            throw new \Exception('Verification of matching record in file 75.1 failed: '.$result);
        }
        
        return $resultPieces[0];
    }

    public static function getRadiologyOrderChecks($mdwsDao, $args) {
//        $id = '99';
//        $name = 'Remote Order Checking not available - checks done on local data only';
//        $level = '2';
//
//        $tmp = array();
//        $tmp['name'] = $name;
//        $tmp['level'] = $level;
//
//        $result[$id] = $tmp;
//        return $result;

        $patientId = $args['patientId'];
        $orderDt = \raptor\StringUtils::convertPhpDateTimeToISO($args['startDateTime']);;
        $locationId = $args['locationIEN'];
        $orderableItemIEN = $args['orderableItemId'];
        
        $soapResult = $mdwsDao->makeQuery('getOrderChecks', 
            array('patientId'=>$patientId, 
                'orderStartDateTime'=>$orderDt, 
                'locationId'=>$locationId, 
                'orderableItem'=>$orderableItemIEN));
        
        $soapResult = $soapResult->getOrderChecksResult;
        
        // massage order check result of 1 to array
        if (!is_array($soapResult->OrderCheckTO)) {
            $soapResult = array($soapResult->OrderCheckTO);
        }
        else {
            $soapResult = $soapResult->OrderCheckTO;
        }
        
        if (isset($soapResult[0]->fault)) {
            throw new \Exception('There was a problem fetching order checks: '.$soapResult[0]->fault->message);
        }
        
        $result = array();
                
        $orderCheckCount = count($soapResult);
        
        for ($i = 0; $i < $orderCheckCount; $i++) {
            $id = $soapResult[$i]->id;
            $name = $soapResult[$i]->name;
            $level = $soapResult[$i]->level;
            
            $tmp = array();
            $tmp['name'] = $name;
            $tmp['level'] = $level;
            
            $result[$id] = $tmp;
        }
        
        return $result;
    }
}

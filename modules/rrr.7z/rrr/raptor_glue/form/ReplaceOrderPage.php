<?php
/**
 * @file
 * ------------------------------------------------------------------------------------
 * Created by SAN Business Consultants for RAPTOR phase 2
 * Open Source VA Innovation Project 2011-2014
 * VA Innovator: Dr. Jonathan Medverd
 * SAN Implementation: Andrew Casertano, Frank Font, et al
 * Contacts: acasertano@sanbusinessconsultants.com, ffont@sanbusinessconsultants.com
 * ------------------------------------------------------------------------------------
 * 
 */ 

namespace raptor;

module_load_include('php', 'raptor_datalayer', 'config/Choices');
module_load_include('php', 'raptor_datalayer', 'core/data_worklist');
module_load_include('php', 'raptor_datalayer', 'core/MdwsUtils');
module_load_include('php', 'raptor_datalayer', 'core/MdwsNewOrderUtils');
module_load_include('php', 'raptor_datalayer', 'core/StringUtils');
//module_load_include('inc', 'raptor_glue', 'functions/replace_order_ajax');
require_once 'FormHelper.php';

/**
 * Implementes the cancel order page.
 *
 * @author Frank Font of SAN Business Consultants
 */
class ReplaceOrderPage extends \raptor\ASimpleFormPage
{
    private $m_oContext = null;
    private $m_oTT = null;

    function __construct()
    {
        $this->m_oContext = \raptor\Context::getInstance();
        $this->m_oTT = new \raptor\TicketTrackingData();
    }

    /**
     * Get the values to populate the form.
     * @return type result of the queries as an array
     */
    function getFieldValues()
    {
        $tid = $this->m_oContext->getSelectedTrackingID();
        if($tid == NULL || trim($tid) == '' || trim($tid) == 0)
        {
            throw new \Exception('Missing selected ticket number!  (If using direct, try overridetid.)');
        }
        $oWL = new \raptor\WorklistData($this->m_oContext);
        $aOneRow = $oWL->getDashboardMap();    //$tid);
        $nSiteID = $this->m_oContext->getSiteID();
        
        $nIEN = $tid;
        $nUID = $this->m_oContext->getUID();
        
        $myvalues = array();
        $myvalues['currentstep'] = 1;
        $myvalues['tid'] = $tid;
        $myvalues['procName'] = $aOneRow['Procedure'];
        $myvalues['reason'] = '';
        $myvalues['notes_tx'] = '';
        $myvalues['esig'] = '';
        $myvalues['cancelreason'] = NULL;
        $myvalues['neworderlocation'] = NULL;
        $myvalues['neworderimagetype'] = NULL;
        $myvalues['neworderlocation'] = NULL;
        $myvalues['neworderitem'] = NULL;
        $myvalues['neworderurgency'] = NULL;
        $myvalues['modecode'] = NULL;
        $myvalues['category'] = NULL;
        $myvalues['submitto'] = NULL;
        $myvalues['isolation'] = NULL;
        $myvalues['pregnant'] = NULL;
        $myvalues['reasonforstudy'] = NULL;
        $myvalues['clinhist'] = NULL;
        $myvalues['datedesired'] = NULL;
        $myvalues['preopdate'] = NULL;
        
        //$this->m_oContext = \raptor\Context::getInstance();
        //$myvalues['tid'] = $this->m_oContext->getSelectedTrackingID();
        $myvalues['OrderFileIen'] = $aOneRow['OrderFileIen'];
        $myvalues['PatientID'] = $aOneRow['PatientID'];

        //TODO: Pre-populate values for display
        return $myvalues;
    }
    
    
    
    /**
     * Some checks to validate the data before we try to save it.
     */
    function looksValidFromFormState($form, $form_state)
    {
        $myvalues = $form_state['values'];
        $goodtrack = array();
        $currentstep = $this->getSubmittedStepNumber($form_state);
        
        if($currentstep == 1)
        {
            $goodtrack[] = FormHelper::validate_number_field_not_empty($myvalues, 'cancelreason', 'Replacement Reason');
            $goodtrack[] = FormHelper::validate_number_field_not_empty($myvalues, 'neworderimagetype', 'Image Type');
        } else
        if($currentstep == 2)
        {
            $goodtrack[] = FormHelper::validate_number_field_not_empty($myvalues, 'neworderlocation', 'Location');
            $goodtrack[] = FormHelper::validate_number_field_not_empty($myvalues, 'neworderitem', 'Order Item');
            $goodtrack[] = FormHelper::validate_number_field_not_empty($myvalues, 'neworderurgency', 'Urgency');
            
            $goodtrack[] = FormHelper::validate_text_field_not_empty($myvalues, 'modecode', 'Transport');
            $goodtrack[] = FormHelper::validate_text_field_not_empty($myvalues, 'category', 'Category');

            $goodtrack[] = FormHelper::validate_number_field_not_empty($myvalues, 'submitto', 'Submit To');
            
            $goodtrack[] = FormHelper::validate_number_field_not_empty($myvalues, 'isolation', 'Isolation');
            $goodtrack[] = FormHelper::validate_number_field_not_empty($myvalues, 'pregnant', 'Pregnant');
            
            $goodtrack[] = FormHelper::validate_text_field_not_empty($myvalues, 'reasonforstudy', 'Reason for Study');
            
            $goodtrack[] = FormHelper::validate_text_field_not_empty($myvalues, 'datedesired', 'Desired Date');
            $goodtrack[] = FormHelper::validate_text_field_not_empty($myvalues, 'preopdate', 'Preop Date');
        } else
        if($currentstep == 3)
        {
            $goodtrack[] = FormHelper::validate_text_field_not_empty($myvalues, 'esig', 'Electronic Signature');
        }
        
        //Check for trouble
        foreach($goodtrack as $value)
        {
            if($value === FALSE)
            {
                //There was trouble.
                return FALSE;
            }
        }
        //There was no trouble, yay!
        return TRUE;
    }
    
    /**
     * Write the values into the database.
     * Return 0 if there was an error, else 1.
     */
    function updateDatabaseFromFormState($form, &$form_state)
    {
        $myvalues = $form_state['values'];
        
        //Try to create the record now
        $nSiteID = $this->m_oContext->getSiteID();
        $nIEN = $myvalues['tid'];
        $orderFileIen = $myvalues['OrderFileIen'];
        $nUID = $this->m_oContext->getUID();
        $sCWFS = $this->m_oTT->getTicketWorkflowState($nSiteID . '-' . $nIEN);
        $updated_dt = date("Y-m-d H:i:s", time());
        
        $reasonCode = $myvalues['cancelreason'];
        $cancelesig = $myvalues['esig'];
        
        drupal_set_message('TODO --- Replace the order now!');
        $oContext = \raptor\Context::getInstance();
        $mdwsDao = $oContext->getMdwsClient();
        $orderChecks = $form_state['orderchecks_result'];
        
        $args = array();
        $args['patientId'] = $myvalues['PatientID'];
        $args['locationIEN'] = $myvalues['neworderlocation'];
        $args['imagingTypeId'] = $myvalues['neworderimagetype'];
        $args['orderableItemId'] = $myvalues['neworderitem'];
        $args['urgencyCode'] = $myvalues['neworderurgency'];
        $args['modeCode'] = $myvalues['modecode'];
        $args['classCode'] = $myvalues['category'];
        $args['submitTo'] = $myvalues['submitto'];
        $args['pregnant'] = $myvalues['pregnant'];
        $args['isolation'] = $myvalues['isolation'];
        $args['reasonForStudy'] = $myvalues['reasonforstudy'];
        $clinhistArray = explode("\n",$myvalues['clinhist']);
        $args['clinicalHx'] = $clinhistArray;
        $args['startDateTime'] = strtotime($myvalues['datedesired']);
        $args['preOpDateTime'] = strtotime($myvalues['preopdate']);
        $args['modifierIds'] = array();  //TODO \StringUtils::joinStrings($args['modifierIds'], '|');
        $args['eSig'] = $myvalues['esig'];
        
        $neworder = MdwsNewOrderUtils::createNewRadiologyOrder($mdwsDao, $orderChecks, $args);
        $form_state['finalstep_result'] = $neworder;
        //$order['radiologyOrderId']
        return TRUE;
        
        try
        {
            $userinfo = $oContext->getUserInfo();
            $mdwsDao = $oContext->getMdwsClient();
            $results = MdwsUtils::cancelRadiologyOrder($mdwsDao, 
                    $myvalues['PatientID'],
                    $orderFileIen,
                    $mdwsDao->getDUZ(),
                    'FakeLocation',
                    $reasonCode, 
                    $cancelesig);
            $cancelled_iens = $results['cancelled_iens'];
            $failed_iens = $results['failed_iens'];
        } catch (\Exception $ex) {
            throw $ex;
        }
        
        $sNewWFS = 'IA';
        $this->m_oTT->setTicketWorkflowState($nSiteID . '-' . $nIEN, $nUID, $sNewWFS, $sCWFS, $updated_dt);

        //Write success message
        drupal_set_message('Replaced Order ' . $myvalues['tid'] . ' (' . $myvalues['procName'] .')');
        
        
        return TRUE;
    }
    
    public static function getStepCount()
    {
        return 3;
    }

    /**
     * Return a code as follows...
     * b = navigate back
     * n = navigate to next
     * f = finish processing
     * NULL = no workflow change
     */
    public static function getWorkflowAction($form_state)
    {
        if(isset($form_state['values']))
        {
            $myvalues = $form_state['values'];
        } else {
            $myvalues = array();
        }
        if(isset($myvalues['navigationoverride']) && $myvalues['navigationoverride'] > '')
        {
            //Allow workflow action to be overridden by value in the field
            $clickedvalue = strtolower($myvalues['navigationoverride']);
            $clickednext = strpos($clickedvalue,'next') !== FALSE;
            $clickedback = strpos($clickedvalue,'back') !== FALSE;
            $clickedfinish = strpos($clickedvalue,'finish') !== FALSE;
        } else {
            //Workflow action is interpretted from the button clicked
            if(isset($form_state['clicked_button']))
            {
                $clickedbutton = $form_state['clicked_button'];
                $clickedvalue = strtolower($clickedbutton['#value']);
                $clickednext = strpos($clickedvalue,'next') !== FALSE;
                $clickedback = strpos($clickedvalue,'back') !== FALSE;
                $clickedfinish = strpos($clickedvalue,'finish') !== FALSE;
            } else {
                $clickedbutton = NULL;
                $clickedvalue = NULL;
                $clickednext = FALSE;
                $clickedback = FALSE;
                $clickedfinish = FALSE;
            }
        }
        if($clickedback)
        {
            return 'b';
        } else
        if($clickednext)
        {
            return 'n';
        } else
        if($clickedfinish)
        {
            return 'f';
        }
        return NULL;
    }
    
    /**
     * Just tell us what step was submitted, not what step we are now on.
     */
    public function getSubmittedStepNumber($form_state)
    {
        if(isset($form_state['values'])) 
        {
            $currentstep = $form_state['step'];
        } else {
            $currentstep = 0;
        }    
        return $currentstep;
    }
    
    /**
     * Get the markup of the form
     */
    public function getForm($form, &$form_state, $disabled, $myvalues)
    {
        //NOTE --- DO NOT MARK FIELDS REQUIRED ELSE DRUPAL VALIDATES ON BACK!!!
        $actioncode = $this->getWorkflowAction($form_state);
        $clickednext = $actioncode == 'n';
        $clickedback = $actioncode == 'b';
        $clickedfinish = $actioncode == 'f';
    
        if(isset($form_state['values'])) 
        {
            if($clickednext || $clickedfinish)
            {
                $currentstep = $form_state['step'] + 1;
            } else if($clickedback) {
                $currentstep = $form_state['step'] - 1;
            }
        } else {
            $currentstep = 1;
        }    
        if($currentstep < 1 || $currentstep > $this->getStepCount())
        {
            throw new \Exception('Cannot have a step = '.$currentstep);
        }
        $form_state['step'] = $currentstep;
        
        //Set flags to adjust UI for steps already been completed
        $disabled_step1 = $disabled || ($currentstep > 1);
        $disabled_step2 = $disabled || ($currentstep > 2);
        
        //Convert this to a hidden field in the production implemenation
        $form['hiddenthings']['navigationoverride'] = array(
            '#type'       => 'hidden',
            '#attributes' =>array('id'=> 'replaceorderstep'),
            '#default_value' => '',
        );
        
        //Hidden values in the form
        //$form['hiddenthings']['navigationoverride'] = array('#type' => 'hidden', '#value' => $myvalues['navigationoverride']);
        $form['hiddenthings']['tid'] = array('#type' => 'hidden', '#value' => $myvalues['tid']);
        $form['hiddenthings']['procName'] = array('#type' => 'hidden', '#value' => $myvalues['procName']);
        $form['hiddenthings']['OrderFileIen'] = array('#type' => 'hidden', '#value' => $myvalues['OrderFileIen']);
        $form['hiddenthings']['PatientID'] = array('#type' => 'hidden', '#value' => $myvalues['PatientID']);
        $form['hiddenthings']['currentstep'] = array('#type' => 'hidden', '#value' => $currentstep);
        if($currentstep != 1)
        {
            $form['hiddenthings']['cancelreason'] = array('#type' => 'hidden', '#value' => $myvalues['cancelreason']);
            $form['hiddenthings']['neworderimagetype'] = array('#type' => 'hidden', '#value' => $myvalues['neworderimagetype']);
        }
        if($currentstep != 2)
        {
            $form['hiddenthings']['neworderlocation'] = array('#type' => 'hidden', '#value' => $myvalues['neworderlocation']);
            $form['hiddenthings']['neworderitem'] = array('#type' => 'hidden', '#value' => $myvalues['neworderitem']);
            $form['hiddenthings']['neworderurgency'] = array('#type' => 'hidden', '#value' => $myvalues['neworderurgency']);
            $form['hiddenthings']['modecode'] = array('#type' => 'hidden', '#value' => $myvalues['modecode']);
            $form['hiddenthings']['category'] = array('#type' => 'hidden', '#value' => $myvalues['category']);
            $form['hiddenthings']['submitto'] = array('#type' => 'hidden', '#value' => $myvalues['submitto']);
            $form['hiddenthings']['isolation'] = array('#type' => 'hidden', '#value' => $myvalues['isolation']);
            $form['hiddenthings']['pregnant'] = array('#type' => 'hidden', '#value' => $myvalues['pregnant']);
            $form['hiddenthings']['clinhist'] = array('#type' => 'hidden', '#value' => $myvalues['clinhist']);
            $form['hiddenthings']['reasonforstudy'] = array('#type' => 'hidden', '#value' => $myvalues['reasonforstudy']);
            $form['hiddenthings']['datedesired'] = array('#type' => 'hidden', '#value' => $myvalues['datedesired']);
            $form['hiddenthings']['preopdate'] = array('#type' => 'hidden', '#value' => $myvalues['preopdate']);
        }
            
        $form['data_entry_area1'] = array(
            '#prefix' => "\n<section class='multistep-dataentry'>"
            . "<H2>Step $currentstep of {$this->getStepCount()}</H2>\n",
            '#suffix' => "\n</section>\n",
            '#disabled' => $disabled,
        );

        //$testdate = date('Ymd.Hi', date("Y-m-d H:i:s"));
            
            
        $mdwsDao = $this->m_oContext->getMdwsClient();
        $aCancelOptions = MdwsUtils::getRadiologyCancellationReasons($mdwsDao);
        $form['data_entry_area1']['toppart']['cancelreason'] = array(
            "#type" => "select",
            "#title" => t("Replacement Reason"),
            "#options" => $aCancelOptions,
            "#description" => t("Select reason for canceling the existing order"),
            "#required" => TRUE,
            "#default_value" => $myvalues['cancelreason'],
            "#disabled" => $disabled_step1,
            );        
        
        $imagetypes = MdwsNewOrderUtils::getImagingTypes($mdwsDao);
        $form['data_entry_area1']['toppart']['neworderimagetype'] = array(
            "#type" => "select",
            "#title" => t("Imaging Type"),
            "#options" => $imagetypes,
            "#description" => t("Select Imaging Type for the new order."),
            "#default_value" => $myvalues['neworderimagetype'],
            "#required" => TRUE,
            "#disabled" => $disabled_step1,
            );
        
        if($currentstep > 1)
        {
            
            //die('LOOKMORE>>>>'.print_r($myvalues,TRUE));
            
            $imagingTypeId = '37';//intval($myvalues['neworderimagetype']); TODO USE THE USER SELECTED VALUE
            $locations = MdwsUtils::getHospitalLocations($mdwsDao);

            if($myvalues['neworderlocation'] === NULL || $myvalues['neworderlocation'] === '')
            {
                $neworderlocation = NULL;
            } else {
                $neworderlocation = $myvalues['neworderlocation'];
            }
            $form['data_entry_area1']['toppart']['neworderlocation'] = array(
                "#type" => "select",
                "#empty_option"=>t('- Select -'),
                "#title" => t("Location")."[$neworderlocation]",
                "#options" => $locations,
                "#description" => t("Select location"),
                "#default_value" => $neworderlocation,
                //"#required" => TRUE,
                "#disabled" => $disabled_step2,
                );        
                
            $raw_orderitems = MdwsNewOrderUtils::getOrderableItems($mdwsDao, $imagingTypeId);
            $orderitems_options = array();
            foreach($raw_orderitems as $k=>$v)
            {
                $orderitems_options[$k] = $v['name'];
            }
            if($myvalues['neworderitem'] === NULL || $myvalues['neworderitem'] === '')
            {
                $neworderitem = NULL;
            } else {
                $neworderitem = $myvalues['neworderitem'];
            }
            $form['data_entry_area1']['toppart']['neworderitem'] = array(
                "#type" => "select",
                "#empty_option"=>t('- Select -'),
                "#title" => t("Orderable Item"),
                "#options" => $orderitems_options,
                "#description" => t("Select orderable item (imaging procedure)"),
                //"#required" => TRUE,
                "#default_value" => $neworderitem,
                "#disabled" => $disabled_step2,
                );        

            $patientId = $myvalues['PatientID'];
            $raworderoptions = MdwsNewOrderUtils::getRadiologyOrderDialog($mdwsDao, $imagingTypeId, $patientId);

            $urgencies = $raworderoptions['urgencies'];
            $form['data_entry_area1']['toppart']['neworderurgency'] = array(
                "#type" => "select",
                "#empty_option"=>t('- Select -'),
                "#title" => t("Urgency"),
                "#options" => $urgencies,
                "#description" => t("Select urgency"),
                //"#required" => TRUE,
                "#default_value" => $myvalues['neworderurgency'],
                "#disabled" => $disabled_step2,
                );        

            $transports = $raworderoptions['transports'];
            $form['data_entry_area1']['toppart']['modecode'] = array(
                "#type" => "select",
                "#empty_option"=>t('- Select -'),
                "#title" => t("Transports"),
                "#options" => $transports,
                "#description" => t("Select mode code"),
                //"#required" => TRUE,
                "#default_value" => $myvalues['modecode'],
                "#disabled" => $disabled_step2,
                );        

            $categories = $raworderoptions['categories'];
            $form['data_entry_area1']['toppart']['category'] = array(
                "#type" => "select",
                "#empty_option"=>t('- Select -'),
                "#title" => t("Category"),
                "#options" => $categories,
                "#description" => t("Select class code"),
                //"#required" => TRUE,
                "#default_value" => $myvalues['category'],
                "#disabled" => $disabled_step2,
                );        

            $submitTo = $raworderoptions['submitTo'];
            $form['data_entry_area1']['toppart']['submitto'] = array(
                "#type" => "select",
                "#empty_option"=>t('- Select -'),
                "#title" => t("Submit To"),
                "#options" => $submitTo,
                "#description" => t("Select the facility for this order"),
                //"#required" => TRUE,
                "#default_value" => $myvalues['submitto'],
                "#disabled" => $disabled_step2,
                );        

            $form['data_entry_area1']['toppart']['isolation'] = array(
                "#type" => "radios",
                "#empty_option"=>t('- Select -'),
                "#title" => t("Isolation"),
                "#options" => array(1=>t('Yes'),2=>t('No'),3=>t('Unknown')),
                //"#required" => TRUE,
                "#default_value" => $myvalues['isolation'],
                "#disabled" => $disabled_step2,
                );        

            $form['data_entry_area1']['toppart']['pregnant'] = array(
                "#type" => "radios",
                "#title" => t("Pregnant"),
                "#options" => array(1=>t('Yes'),2=>t('No'),3=>t('Unknown')),
                //"#required" => TRUE,
                "#default_value" => $myvalues['pregnant'],
                "#disabled" => $disabled_step2,
                );        

            $form['data_entry_area1']['toppart']['reasonforstudy'] = array(
                '#type'          => 'textfield',
                '#title'         => t('Reason for Study'),
                '#size' => 64, 
                '#maxlength' => 64, 
                '#default_value' => '',
                "#description" => t('Provide short reason for study.  (64 characters maximum)'),
                //'#required' => TRUE,
                "#default_value" => $myvalues['reasonforstudy'],
                "#disabled" => $disabled_step2,
            );

            $form['data_entry_area1']['toppart']['clinhist'] = array(
                '#type'          => 'textarea',
                '#title'         => t('Clinical History'),
                "#disabled" => $disabled_step2,
                "#default_value" => $myvalues['clinhist'],
            );

            if(isset($myvalues['datedesired']))
            {
                $datedesired = $myvalues['datedesired'];
            } else {
                $datedesired = NULL;
            }
            $form['data_entry_area1']['toppart']['datedesired'] = array(
                '#type' => 'textfield',
                '#size' => 20, 
                '#maxlength' => 20, 
                '#title'     => t('Date Desired'),
                "#disabled" => $disabled_step2,
                //'#required' => TRUE,
                "#default_value" => $datedesired,
                "#description" => t('When would you like for this procedure to occur? (M/D/YYYY HH:MM military time)'),
            );

            if(isset($myvalues['preopdate']))
            {
                $preopdate = $myvalues['preopdate'];
            } else {
                $preopdate = NULL;
            }
            $form['data_entry_area1']['toppart']['preopdate'] = array(
                '#type'          => 'textfield',
                '#size' => 20, 
                '#maxlength' => 20, 
                '#title'         => t('PreOp Scheduled'),
                "#disabled" => $disabled_step2,
                //'#required' => TRUE,
                "#default_value" => $preopdate,
                "#description" => t('What is the preop date? (M/D/YYYY HH:MM military time)'),
            );

            if($currentstep == $this->getStepCount())
            {
                //die('LOOK FINAL>>>'.print_r($myvalues,TRUE));
                
                //Final step
                $args = array();
                $args['patientId'] = $myvalues['PatientID'];
                
                $date = new \DateTime();
                $timestamp = $date->getTimestamp(); 
                
                $startdatetime = strtotime($myvalues['datedesired']);
                $args['startDateTime'] = $startdatetime;   //$timestamp;// //Ymd.Hi TODO $myvalues['datedesired'];
                
                $args['locationIEN'] = $myvalues['neworderlocation'];
                $args['orderableItemId'] = $myvalues['neworderitem'];
                $rawchecks = MdwsNewOrderUtils::getRadiologyOrderChecks($mdwsDao, $args);
                $form_state['orderchecks_result'] = $rawchecks;
                
                //die('LOOKNOW>>>>'.print_r($rawchecks,TRUE));
                
                $checkresultitems = array();
                foreach($rawchecks as $key=>$value)
                {
                    $checkresultitems[$key] = $value['name'];
                }
                $checkresulthtml = implode('<li>',$checkresultitems);
                $form['data_entry_area1']['toppart']['confirmationinfo'] = array(
                    '#prefix' => "\n<section class='generic-warning-area'>\n"
                    . '<p><ol>'
                    . $checkresulthtml
                    . '</ol></p>',
                    '#suffix' => "\n</section>\n",
                    '#disabled' => $disabled,
                );
                
                $form['data_entry_area1']['toppart']['esig'] = array(
                    '#type'          => 'password',
                    '#title'         => t('Electronic Signature'),
                    '#disabled'      => $disabled,
                    '#size' => 55, 
                    '#maxlength' => 128, 
                    '#default_value' => '',
                    //'#required' => TRUE,
                );
            }
        }
         
       
        $form['data_entry_area1']['action_buttons'] = array(
            '#prefix' => "\n<section class='raptor-action-buttons'>\n",
            '#suffix' => "\n</section>\n",
            '#disabled' => $disabled,
        );
        /*
        $form['data_entry_area1']['action_buttons']['remove'] = array('#type' => 'submit'
                ,'#id' => 'replace-order-submit-button' //alex edits
                , '#attributes' => array('class' => array('admin-action-button'))
                , '#value' => t('Cancel Existing Imaging Order and Create This New Order')
                , '#disabled' => $disabled
        );
        */
        if($currentstep > 1)
        {
            $form['data_entry_area1']['action_buttons']['back'] = array('#type' => 'submit'
                    ,'#id' => 'replace-order-submit-back-button' //alex edits
                    , '#attributes' => array('class' => array('admin-action-button'))
                    , '#value' => t('<< Back')
                    //, '#limit_validation_errors' => array()
                    , '#disabled' => $disabled
            );
        }
        
        if($currentstep == $this->getStepCount())
        {
            $form['data_entry_area1']['action_buttons']['next'] = array('#type' => 'submit'
                    ,'#id' => 'replace-order-submit-next-button' //alex edits
                    , '#attributes' => array('class' => array('admin-action-button'))
                    , '#value' => t('Finish >>')
                    , '#disabled' => $disabled
            );
        } else {
            $form['data_entry_area1']['action_buttons']['next'] = array('#type' => 'submit'
                    ,'#id' => 'replace-order-submit-next-button' //alex edits
                    , '#attributes' => array('class' => array('admin-action-button'))
                    , '#value' => t('Next >>')
                    , '#disabled' => $disabled
            );
        }
        
        
        
        $form['data_entry_area1']['action_buttons']['cancel'] = array('#type' => 'item'
                , '#markup' => '<input class="raptor-dialog-cancel" type="button" value="Exit with No Changes">');
 
        
        return $form;
    }
}


<?php
/**
 * @file
 * ------------------------------------------------------------------------------------
 * Created by SAN Business Consultants for RAPTOR phase 2
 * Open Source VA Innovation Project 2011-2014
 * VA Innovator: Dr. Jonathan Medverd
 * SAN Implementation: Andrew Casertano, Frank Font, et al
 * Contacts: acasertano@sanbusinessconsultants.com, ffont@sanbusinessconsultants.com
 * ------------------------------------------------------------------------------------
 * 
 */ 


namespace raptor;

/**
 * This class is used to manage the ticket tracking information.
 *
 * @author SAN
 */
class TicketTrackingData 
{
    /**
     * Generate a unique tracking ID from immutable elements of one record from data store
     * The system can use this ID to then find one and only one record in the data store
     * @return string
     */
    public function getTrackingID($nSiteID, $nIEN)
    {
        return $nSiteID . '-' . $nIEN;
    }
    
    /**
     * Tell us what the ticket type is from the tracking ID
     * @param type $aTrackingID
     * @return string
     */
    public function getTicketType($sTrackingID)
    {
        $sCWFS = $this->getTicketWorkflowState($sTrackingID);
        return $this->getTicketTypeFromWorflowState($sCWFS);
    }

    /**
     * Tell us what the ticket type is from the workflow state of the ticket.
     * @param type $sCWFS current workflow state
     * @return string
     * @deprecated since version raptor_workflow module
     */
    public function getTicketTypeFromWorflowState($sCWFS)
    {
        if($sCWFS == 'AC' || $sCWFS == 'CO' || $sCWFS == 'RV')
        {
            $sType = 'P';
        } else
        if($sCWFS == 'AP' || $sCWFS == 'PA')
        {
            $sType = 'E';
        } else
        if($sCWFS == 'EC')
        {
            $sType = 'I';
        } else
        if($sCWFS == 'QA' || $sCWFS == 'IA')
        {
            $sType = 'Q';
        } else {
            $sType = NULL;
            drupal_set_message('Did NOT find a valid ticket type for ' . $sTrackingID);
        }
        return $sType;
    }

    /**
     * @deprecated since version raptor_workflow module
     */
    public static function getTicketPhraseFromWorflowState($sCWFS)
    {
        if($sCWFS == 'AC')
        {
            $sPhrase = 'Active';
        } else
        if($sCWFS == 'CO')
        {
            $sPhrase = 'Collaboration';
        } else
        if($sCWFS == 'RV')
        {
            $sPhrase = 'Review';
        } else
        if($sCWFS == 'AP')
        {
            $sPhrase = 'Approved';
        } else
        if($sCWFS == 'PA')
        {
            $sPhrase = 'Protocol Acknowledged';
        } else
        if($sCWFS == 'EC')
        {
            $sPhrase = 'Exam Completed';
        } else
        if($sCWFS == 'QA')
        {
            $sPhrase = 'Quality Assurance';
        } else
        if($sCWFS == 'IA')
        {
            $sPhrase = 'Suspended';
        } else {
            $sPhrase = NULL;
            drupal_set_message('Did NOT find a valid ticket type phrase from type =[' . $sCWFS .']');
        }
        return $sPhrase;
    }
    
    /**
     * Return the workflow state of a ticket.
     * @param type $sTrackingID must be "SiteID-IEN"
     * @return string
     */
    public function getTicketWorkflowState($sTrackingID)
    {
        $aParts = $this->getTrackingIDParts($sTrackingID);
        $nSiteID = $aParts[0];
        $nIEN = $aParts[1];
        $aWorkflowStateRecord = db_select('raptor_ticket_tracking', 'n')
            ->fields('n')
            ->condition('siteid', $nSiteID,'=')
            ->condition('IEN', $nIEN,'=')
            ->execute()
            ->fetchAssoc();       
        if(!isset($aWorkflowStateRecord['workflow_state']) || $aWorkflowStateRecord['workflow_state'] == '')
        {
            $sCWFS = 'AC';
            //drupal_set_message('Did not find ticket tracking record for '.$nSiteID.'-'.$nIEN);
        } else {
            $sCWFS = $aWorkflowStateRecord['workflow_state'];
        } 
        return $sCWFS;        
    }
    
    /**
     * Returns array if ticket assignment info if ticket is in collaborate mode.
     * Use is_array to see if in collaborate mode.
     * @param type $sTrackingID
     */
    public function getCollaborationInfo($sTrackingID)
    {
        $return = NULL;
        $aParts = $this->getTrackingIDParts($sTrackingID);
        $nSiteID = $aParts[0];
        $nIEN = $aParts[1];
        $result = db_select('raptor_ticket_collaboration','p')
                ->fields('p')
                ->condition('siteid',$nSiteID,'=')
                ->condition('IEN',$nIEN,'=')
                ->execute();
        if($result == NULL)
        {
            $nRows = 0;
        } else {
            $nRows = $result->rowCount();
        }
        if($nRows > 0)
        {
            //Return the fields of the found record.
            $return = $result->fetchAssoc();
        }
        return $return;
    }
    
    /**
     * Set or clear the collaboration status of a ticket.
     * @param type $sCWFS current workflow status
     */
    public function setCollaborationUser($sTrackingID, $nRequesterUID, $sRequesterNote, $nCollaboratorUID, $sCWFS=NULL, $updated_dt=NULL)
    {
        $successMsg = NULL;
        if($sCWFS == NULL)
        {
            $sCWFS = $this->getTicketWorkflowState($sTrackingID);
        }
        if($updated_dt == NULL)
        {
            $updated_dt = date("Y-m-d H:i:s", time());
        }
        $aParts = $this->getTrackingIDParts($sTrackingID);
        $nSiteID = $aParts[0];
        $nIEN = $aParts[1];

        //Make sure we are okay to reserve this ticket.
        if($sCWFS !== 'AC' && $sCWFS !== 'AP' && $sCWFS !== 'CO' && $sCWFS !== 'RV')
        {
            $msg = 'Only tickets in the active or approved or collaborate status can be reserved!  Ticket ' . $sTrackingID . ' is in the [' .$sCWFS. '] state!';
            error_log($msg);
            die($msg);
        }

        //Create the raptor_ticket_collaboration record now
        try
        {
            if($nCollaboratorUID == NULL)
            {
                //Simply delete the existing collaboration record if it exists.
                $num_deleted = db_delete('raptor_ticket_collaboration')
                    ->condition('siteid',$nSiteID,'=')
                    ->condition('IEN',$nIEN,'=')
                    ->execute();
                $successMsg = 'Ticket '.$sTrackingID.' is longer assigned to anyone.';
            } else {
                $result = db_select('raptor_ticket_collaboration','p')
                        ->fields('p')
                        ->condition('siteid',$nSiteID,'=')
                        ->condition('IEN',$nIEN,'=')
                        ->condition('collaborator_uid',$nCollaboratorUID,'=')
                        ->execute();
                if($result == NULL)
                {
                    $nRows = 0;
                } else {
                    $nRows = $result->rowCount();
                }
                if($nRows > 0)
                {
                    $successMsg = 'Already assigned ' . $sTrackingID;
                } else {
                    $result = db_select('raptor_ticket_collaboration','p')
                            ->fields('p')
                            ->condition('siteid',$nSiteID,'=')
                            ->condition('IEN',$nIEN,'=')
                            ->condition('collaborator_uid',$nCollaboratorUID,'<>')
                            ->execute();
                    if($result == NULL)
                    {
                        $nRows = 0;
                    } else {
                        $nRows = $result->rowCount();
                    }
                    $oInsert = db_merge('raptor_ticket_collaboration')
                            ->key(array('siteid' => $nSiteID,'IEN' => $nIEN,))
                            ->fields(array(
                                'siteid' => $nSiteID,
                                'IEN' => $nIEN,
                                'requester_uid' => $nRequesterUID,
                                'requested_dt' => $updated_dt,
                                'requester_notes_tx' => $sRequesterNote,
                                'collaborator_uid' => $nCollaboratorUID,
                                'active_yn' => 1,
                            ))
                            ->execute();
                    if($nRows > 0)
                    {
                        $successMsg = 'Replaced other user assignment ' . $sTrackingID;
                    } else {
                        $successMsg = 'Assigned other user assignment ' . $sTrackingID;
                    }
                }
            }
        }
        catch(\Exception $e)
        {
            error_log('Failed to create raptor_ticket_collaboration: ' . $e . "\nDetails..." . print_r($oInsert,true));
            die('Failed to reserve this ticket!');
            return 0;
        }

        //Did we collaborate or remove collaboration?
        if($sCWFS == 'CO' && $nCollaboratorUID == NULL)
        {
            //AC is the non-collaboration equivalent of CO
            $sNewWFS = 'AC'; 
        } else if($sCWFS == 'AC' && $nCollaboratorUID !== NULL) {
            //CO is the collaboration equivalent of AC
            $sNewWFS = 'CO'; 
        }
        $this->setTicketWorkflowState($sTrackingID, $nRequesterUID, $sNewWFS, $sCWFS, $updated_dt);
        
        return $successMsg;
    }
    
    /**
     * Update the database
     * @return int Description 0 for failed, 1 for success
     */
    public function setTicketWorkflowState($sTrackingID, $nUID, $sNewWFS, $sCWFS=NULL, $updated_dt=NULL)
    {
        if($sCWFS == NULL)
        {
            $sCWFS = $this->getTicketWorkflowState($sTrackingID);
        }
        if($updated_dt == NULL)
        {
            $updated_dt = date("Y-m-d H:i:s", time());
        }
        $aParts = $this->getTrackingIDParts($sTrackingID);
        $nSiteID = $aParts[0];
        $nIEN = $aParts[1];
        
        //Try to create the raptor_ticket_tracking record now
        try
        {
            $aFields = array(
                        'siteid' => $nSiteID,
                        'IEN' => $nIEN,
                        'workflow_state' => $sNewWFS,
                        'updated_dt' => $updated_dt,
                );
            if($sNewWFS == 'AP')
            {
                $aFields['approved_dt'] = $updated_dt;
            }
            if($sNewWFS == 'EC')
            {
                $aFields['exam_completed_dt'] = $updated_dt;
            }
            if($sCWFS !== 'QA' && $sNewWFS == 'QA') //20140808
            {
                $aFields['interpret_completed_dt'] = $updated_dt;
            }
            if($sCWFS === 'QA' && $sNewWFS == 'QA') //20140808
            {
                $aFields['qa_completed_dt'] = $updated_dt;
            }
            if($sNewWFS == 'IA')
            {
                $aFields['suspended_dt'] = $updated_dt;
            }
            $oInsert = db_merge('raptor_ticket_tracking')
                    ->key(array('siteid'=>$nSiteID, 'IEN'=>$nIEN))
                    ->fields($aFields)
                    ->execute();
        }
        catch(\Exception $e)
        {
            error_log('Failed to update raptor_ticket_tracking: ' . $e);
            drupal_set_message('Failed to change workflow status of this ticket!','error');
            return 0;
        }

        //Create the raptor_ticket_workflow_history record now
        try
        {
            $oInsert = db_insert('raptor_ticket_workflow_history')
                    ->fields(array(
                        'siteid' => $nSiteID,
                        'IEN' => $nIEN,
                        'initiating_uid' => $nUID,
                        'old_workflow_state' => $sCWFS,
                        'new_workflow_state' => $sNewWFS,
                        'created_dt' => $updated_dt,
                    ))
                    ->execute();
        }
        catch(\Exception $e)
        {
            error_log('Failed to create raptor_ticket_workflow_history: ' . $e . "\nDetails..." . print_r($oInsert,true));
            drupal_set_message('Failed to save history for this ticket!','error');
            return 0;
        }
        return 1;
    }
    
    /**
     * Delete all lock records for a user.
     */
    public function deleteAllUserTicketLocks($nUID, $entire_delete_reason=NULL)
    {
        if($entire_delete_reason != NULL)
        {
            error_log($entire_delete_reason);
        }
        try
        {
            $query = db_delete('raptor_ticket_lock_tracking')
                ->condition('locked_by_uid', $nUID,'=')
                    ->execute();
        } catch (\Exception $ex) {
            throw $ex;
        }
    }

    private function deleteUserTicketLocks($nSiteID, $locked_by_uid, $locktype='E')
    {
        try
        {
            $query = db_delete('raptor_ticket_lock_tracking')
                ->condition('siteid', $nSiteID,'=');
            $query->condition('locked_by_uid', $locked_by_uid, '=');
            if($locktype !== NULL)
            {
                $query->condition('locked_type_cd', $locktype, '=');
            }
            $deleted = $query->execute();            
        } catch (\Exception $ex) {
            error_log('Failed to delete locks for user '.$locked_by_uid.' because '.$ex->getMessage());
            throw $ex;
        }
    }
    
    /**
     * Delete any kind of lock record
     */
    private function deleteTicketLock($sTrackingID, $locked_by_uid=NULL
            , $entire_delete_reason=NULL
            , $locktype=NULL, $filteroperator='=')
    {
        $aParts = $this->getTrackingIDParts($sTrackingID);
        $nSiteID = $aParts[0];
        $nIEN = $aParts[1];
        $deleted = 0;
        try
        {
            $query = db_delete('raptor_ticket_lock_tracking')
                ->condition('siteid', $nSiteID,'=')
                ->condition('IEN', $nIEN,'=');
            if($locked_by_uid != NULL)
            {
                $query->condition('locked_by_uid', $locked_by_uid, '=');
            }
            if($locktype != NULL)
            {
                $query->condition('locked_type_cd', $locktype, $filteroperator);
            }
            $deleted = $query->execute();            
        } catch (\Exception $ex) {
            error_log('Failed to delete '.$sTrackingID.' because '.$ex->getMessage());
            throw $ex;
        }
        if($deleted == 1)
        {
            if($entire_delete_reason != NULL)
            {
                error_log($entire_delete_reason);
            }
        } else {
            error_log('Expected to delete one ticket="'.$sTrackingID.'"'
                    . ' but instead deleted '.$deleted.' records!'
                    . ' >>>query='.print_r($query,TRUE)
                    );
        }
        return $deleted;
    }
    
    /**
     * Delete an edit lock record
     */
    public function deleteTicketEditLock($sTrackingID, $uid=NULL, $delete_reason=NULL)
    {
        $aParts = $this->getTrackingIDParts($sTrackingID);
        $nSiteID = $aParts[0];
        $nIEN = $aParts[1];
        if($delete_reason != NULL)
        {
            $entire_delete_reason = 'Deleting edit lock for '.$sTrackingID.' because '.$delete_reason;
        } else {
            $entire_delete_reason = NULL;
        }
        return $this->deleteTicketLock($sTrackingID, $uid, $entire_delete_reason, 'E', '=');
    }

    /**
     * Delete a non-edit lock record
     */
    public function deleteTicketNonEditLock($sTrackingID, $delete_reason=NULL)
    {
        $aParts = $this->getTrackingIDParts($sTrackingID);
        $nSiteID = $aParts[0];
        $nIEN = $aParts[1];
        if($delete_reason != NULL)
        {
            $entire_delete_reason = 'Deleting non-edit lock for '.$sTrackingID.' because '.$delete_reason;
        } else {
            $entire_delete_reason = NULL;
        }
        $this->deleteTicketLock($sTrackingID, NULL, $entire_delete_reason, 'E', '<>');
    }

    /**
     * Get details for all current record locks
     *   details[tickets][tid] <-- lookup the ticket here
     *   details[users][uid] <-- lookup the fullname here
     */
    public function getAllTicketLockDetails()
    {
        $details = array();
        $details['tickets'] = array();
        $details['users'] = array();

        $this->deleteAllStaleTicketLocks(VISTA_SITE);
        
        $query = db_select('raptor_ticket_lock_tracking', 'n');
        $query->join('raptor_user_profile', 'u', 'n.locked_by_uid = u.uid');
        $query->fields('n');
        $query->fields('u', array('username','usernametitle','firstname','lastname','suffix'))
            ->orderBy('IEN');
        $result = $query->execute();
        while($record = $result->fetchAssoc())
        {
            $oneticket = array();
            $oneticket['siteid'] = $record['siteid'];
            $oneticket['IEN'] = $record['IEN'];
            $oneticket['locked_type_cd'] = $record['locked_type_cd'];
            $oneticket['lock_started_dt'] = $record['lock_started_dt'];
            $oneticket['lock_refreshed_dt'] = $record['lock_refreshed_dt'];
            $lbuid = $record['locked_by_uid'];
            $oneticket['locked_by_uid'] = $lbuid;
            $sTID = $record['siteid'].'-'.$record['IEN'];
            $details['tickets'][$sTID] = $oneticket;
            if(!isset($details['users'][$lbuid]))
            {
                //Add this user to the lookup information.
                $fullname = trim($record['usernametitle'] . ' ' . $record['firstname'] . ' ' . $record['lastname'] . ' ' . $record['suffix']);
                $oneuser = array();
                $oneuser['uid'] = $lbuid;
                $oneuser['fullname'] = $fullname;
                $details['users'][$lbuid] = $oneuser;
            }
        }
        return $details;
    }
    
    
    /**
     * Get details for one or more lock records of a ticket
     */
    public function getTicketLockDetails($sTrackingID
            ,$locktypefilter='E'
            ,$uidfilter=NULL
            ,$limit_one_rec=TRUE)
    {
        $aParts = $this->getTrackingIDParts($sTrackingID);
        $nSiteID = $aParts[0];
        $nIEN = $aParts[1];
        $query = db_select('raptor_ticket_lock_tracking', 'n')
            ->fields('n')
            ->condition('siteid', $nSiteID,'=')
            ->condition('IEN', $nIEN,'=');
        if($locktypefilter !== NULL)
        {
            //Apply the filter.
            $query->condition('locked_type_cd', $locktypefilter,'=');
        }
        if($uidfilter !== NULL)
        {
            //Apply the filter.
            $query->condition('locked_by_uid', $uidfilter,'=');
        }
        $result = $query->execute();
        if($result != NULL && $result->rowCount() > 0)
        {
            if($limit_one_rec && $result->rowCount() > 1)
            {
                throw new \Exception('Too many edit lock records ('
                        .$result->rowCount().') found for '
                        .$sTrackingID.'>>>'.print_r($result,TRUE));
            }
            //Return the lock record details as an array.
            return $result->fetchAssoc();       
        }
        //No lock record found.
        return NULL;
    }
    
    /**
     * Delete all the stale records
     */
    public function deleteAllStaleTicketLocks($nSiteID, $extralogmessage=NULL)
    {
        $maxage = USER_EDITLOCK_TIMEOUT_SECONDS;
        $oldestallowed_dt = date("Y-m-d H:i:s", time() - $maxage);
        $query = db_select('raptor_ticket_lock_tracking', 'n');
        $query->leftJoin('sessions', 'u', 'n.locked_by_uid = u.uid');
        $query->fields('n');
        $query->fields('u', array('uid'));
        $query->condition('n.siteid', $nSiteID,'=');
        $db_or = db_or();
        $db_or->condition('n.lock_refreshed_dt', $oldestallowed_dt,'<');
        $db_or->isNull('u.uid');
        $query->condition($db_or);
        $result = $query->execute();
        foreach($result as $row)
        {
            $sTrackingID = $nSiteID.'-'.$row->IEN;
            $currently_locked_by_uid = $row->locked_by_uid;
            if($row->uid  == NULL)
            {
                $entire_delete_reason = 'Deleted stale lock on '.$sTrackingID.' because '.$currently_locked_by_uid.' user is not logged in >>> '.print_r($row,TRUE);
            } else {
                $entire_delete_reason = 'Deleted stale lock on '.$sTrackingID.' because lock too old >>> '.print_r($row,TRUE);
            }
            if($extralogmessage != NULL)
            {
                $entire_delete_reason .= ' ('.$extralogmessage.')';
            }
            $this->deleteTicketLock($sTrackingID, $currently_locked_by_uid, $entire_delete_reason);
        }
    }
    
    /**
     * Queries the database to see if ticket is locked by other user for editing
     * @return boolean
     */
    public function isTicketEditLockedByOtherUser($sTrackingID, $nUID)
    {
        $lockrec = $this->getTicketLockDetails($sTrackingID);
        if($lockrec == NULL)
        {
            //No edit lock exists.
            return FALSE;
        }
        
        //See if lock is still valid.
        $nowtime = time();
        $lockage = $nowtime - $lockrec['lock_refreshed_dt'];
        if($lockage > USER_TIMEOUT_SECONDS + USER_TIMEOUT_GRACE_SECONDS)
        {
            //Ticket is too old, kill it!
            $delete_reason = 'expired lock record: '.print_r($lockrec,TRUE);
            $this->deleteTicketEditLock($sTrackingID, NULL, $delete_reason);
            //No lock exists now.
            return FALSE;
        }
                
        //Locked by another user?
        return ($lockrec['locked_by_uid'] != $nUID);
    }
    
    /**
     * Update the timestamp on an existing ticket lock record
     */
    public function updateTicketEditLock($sTrackingID, $nUID, $updated_dt = NULL)
    {
        $aParts = $this->getTrackingIDParts($sTrackingID);
        $nSiteID = $aParts[0];
        $nIEN = $aParts[1];
        if($updated_dt == NULL)
        {
            $updated_dt = date("Y-m-d H:i:s", time());
        }
        $num_updated = 0;
        try
        {
            $num_updated  = db_update('raptor_ticket_lock_tracking')
                    ->fields(array(
                        'lock_refreshed_dt' => $updated_dt,
                    ))
                    ->condition('siteid',$nSiteID,'=')
                    ->condition('IEN', $nIEN,'=')
                    ->condition('locked_type_cd','E','=')
                    ->condition('locked_by_uid',$nUID,'=')
                    ->execute();
        } catch (\Exception $ex) {
            error_log('Failed to update edit lock for '.$sTrackingID.' because '.print_r($ex,TRUE));
            throw $ex;
        }
        if($num_updated !== 1)
        {
            throw new \Exception('Expected to update one ticket edit lock for '.$sTrackingID.' but instead updated '.$num_updated);
        }
    }
    
    /**
     * Return parts of the tracking ID and throw exception if anything missing
     */
    private function getTrackingIDParts($sTrackingID)
    {
        $aParts = explode('-',$sTrackingID);
        if(count($aParts) !== 2)
        {
            throw new \Exception('Invalid format for tracking ID "'
                    .$sTrackingID.'"!');
        }
        return $aParts;
    }
    
    /**
     * Update the ticket as locked for editing
     * Release other edit locks (only one allowed at a time)
     */
    public function markTicketEditLocked($sTrackingID, $nUID, $updated_dt = NULL)
    {
        $lockrec = $this->getTicketLockDetails($sTrackingID);
        if($lockrec != NULL)
        {
            if($lockrec['locked_by_uid'] != $nUID)
            {
                throw new \Exception('Cannot mark '.$sTrackingID
                        .' with edit lock because already locked '
                        .print_r($lockrec,TRUE));
            }
            //Already locked.
            return;
        }
        $aParts = $this->getTrackingIDParts($sTrackingID);
        $nSiteID = $aParts[0];
        $nIEN = $aParts[1];
        if($updated_dt == NULL)
        {
            $updated_dt = date("Y-m-d H:i:s", time());
        }
        $this->deleteUserTicketLocks($nSiteID,$nUID);   //Delete all existing Edit locks now
        try
        {
            db_insert('raptor_ticket_lock_tracking')
                ->fields(array(
                    'siteid' => $nSiteID,
                    'IEN' => $nIEN,
                    'locked_by_uid' => $nUID,
                    'locked_type_cd' => 'E',
                    'lock_started_dt' => $updated_dt,
                    'lock_refreshed_dt' => $updated_dt,
                ))
                ->execute();
        } catch (\Exception $ex) {
            error_log('Failed to insert edit lock for '.$sTrackingID
                    .' because '.print_r($ex,TRUE));
            throw $ex;
        }
    }

    /**
     * Verify no other user has the lock and then delete it
     */
    public function markTicketUnlocked($sTrackingID, $nUID)
    {
        //Check for an existing edit lock first.
        $lockrec = $this->getTicketLockDetails($sTrackingID,'E');
        if($lockrec != NULL)
        {
            //Found an edit lock.
            if($lockrec['locked_by_uid'] != $nUID)
            {
                //Try again after killing all stale tickets
                $this->deleteAllStaleTicketLocks(VISTA_SITE);   
                $lockrec = $this->getTicketLockDetails($sTrackingID,'E');
                if($lockrec['locked_by_uid'] != $nUID)
                {
                    //Hmm, was not a stale ticket.
                    throw new \Exception('User '.$nUID
                       .' cannot delete edit lock on '
                       .$sTrackingID
                       .' because it belongs to '
                       .$lockrec['locked_by_uid']);
                }
            }
            $this->deleteTicketEditLock($sTrackingID);
        } else {
            //No edit lock, but there may be other kinds. (e.g., View)
            $lockrec = $this->getTicketLockDetails($sTrackingID,NULL,$nUID);
            if($lockrec != NULL)
            {
                $this->deleteTicketNonEditLock($sTrackingID);
            }
        }
    }
}

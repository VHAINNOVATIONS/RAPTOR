<?php
/**
 * @file
 * ------------------------------------------------------------------------------------
 * Created by SAN Business Consultants for RAPTOR phase 2
 * Open Source VA Innovation Project 2011-2014
 * VA Innovator: Dr. Jonathan Medverd
 * SAN Implementation: Andrew Casertano, Frank Font, et al
 * Contacts: acasertano@sanbusinessconsultants.com, ffont@sanbusinessconsultants.com
 * ------------------------------------------------------------------------------------
 * 
 */ 

namespace raptor;

module_load_include('php', 'raptor_datalayer', 'config/Choices');
module_load_include('php', 'raptor_datalayer', 'core/data_worklist');
module_load_include('php', 'raptor_datalayer', 'core/data_dashboard');
module_load_include('php', 'raptor_datalayer', 'core/MdwsUtils');
module_load_include('php', 'raptor_datalayer', 'core/MdwsNewOrderUtils');
module_load_include('php', 'raptor_datalayer', 'core/StringUtils');
//module_load_include('inc', 'raptor_glue', 'functions/replace_order_ajax');
require_once 'FormHelper.php';

/**
 * Implementes the cancel order page.
 *
 * @author Frank Font of SAN Business Consultants
 */
class ReplaceOrderPage extends \raptor\ASimpleFormPage
{
    private $m_oContext = null;
    private $m_oTT = null;

    function __construct()
    {
        $this->m_oContext = \raptor\Context::getInstance();
        $this->m_oTT = new \raptor\TicketTrackingData();
    }

    /**
     * Get the values to populate the form.
     * @return type result of the queries as an array
     */
    function getFieldValues()
    {
        $tid = $this->m_oContext->getSelectedTrackingID();
        if($tid == NULL || trim($tid) == '' || trim($tid) == 0)
        {
            throw new \Exception('Missing selected ticket number!  (If using direct, try overridetid.)');
        }
        $oWL = new \raptor\WorklistData($this->m_oContext);
        $aOneRow = $oWL->getDashboardMap();    //$tid);
        $nSiteID = $this->m_oContext->getSiteID();

        $nIEN = $tid;
        $nUID = $this->m_oContext->getUID();
        
        $myvalues = array();
        $myvalues['currentstep'] = 1;
        $myvalues['tid'] = $tid;
        $myvalues['procName'] = $aOneRow['Procedure'];
        $myvalues['reason'] = '';
        $myvalues['notes_tx'] = '';
        $myvalues['esig'] = '';
        $myvalues['cancelreason'] = NULL;
        $myvalues['neworderlocation'] = NULL;
        $myvalues['neworderimagetype'] = NULL;
        $myvalues['neworderlocation'] = NULL;
        $myvalues['neworderitem'] = NULL;
        $myvalues['neworderurgency'] = NULL;
        $myvalues['modecode'] = NULL;
        $myvalues['category'] = NULL;
        $myvalues['submitto'] = NULL;
        $myvalues['isolation'] = NULL;
        $myvalues['pregnant'] = NULL;
        $myvalues['reasonforstudy'] = NULL;
        $myvalues['clinhist'] = NULL;
        $myvalues['datedesired_dateonly'] = NULL;
        $myvalues['preopdate_dateonly'] = NULL;
        $myvalues['datedesired_timeonly'] = NULL;
        $myvalues['preopdate_timeonly'] = NULL;
        
        //$this->m_oContext = \raptor\Context::getInstance();
        //$myvalues['tid'] = $this->m_oContext->getSelectedTrackingID();
        $myvalues['OrderFileIen'] = $aOneRow['OrderFileIen'];
        $myvalues['PatientID'] = $aOneRow['PatientID'];

        //TODO: Pre-populate values for display
        return $myvalues;
    }
    
    
    
    /**
     * Some checks to validate the data before we try to save it.
     */
    function looksValidFromFormState($form, $form_state)
    {
        $myvalues = $form_state['values'];
        $goodtrack = array();
        $currentstep = $this->getSubmittedStepNumber($form_state);
        
        if($currentstep == 1)
        {
            $goodtrack[] = FormHelper::validate_number_field_not_empty($myvalues, 'cancelreason', 'Replacement Reason');
            $goodtrack[] = FormHelper::validate_number_field_not_empty($myvalues, 'neworderimagetype', 'Image Type');
        } else
        if($currentstep == 2)
        {
            $goodtrack[] = FormHelper::validate_number_field_not_empty($myvalues, 'neworderlocation', 'Location');
            $goodtrack[] = FormHelper::validate_number_field_not_empty($myvalues, 'neworderitem', 'Order Item');
            $goodtrack[] = FormHelper::validate_number_field_not_empty($myvalues, 'neworderurgency', 'Urgency');
            
            $goodtrack[] = FormHelper::validate_text_field_not_empty($myvalues, 'modecode', 'Transport');
            $goodtrack[] = FormHelper::validate_text_field_not_empty($myvalues, 'category', 'Category');

            $goodtrack[] = FormHelper::validate_number_field_not_empty($myvalues, 'submitto', 'Submit To');
            
            $goodtrack[] = FormHelper::validate_number_field_not_empty($myvalues, 'isolation', 'Isolation');
            $goodtrack[] = FormHelper::validate_number_field_not_empty($myvalues, 'pregnant', 'Pregnant');
            
            $goodtrack[] = FormHelper::validate_text_field_not_empty($myvalues, 'reasonforstudy', 'Reason for Study');
            
            $goodtrack[] = FormHelper::validate_date_field_not_empty($myvalues, 'datedesired_dateonly', 'Desired Date');
            $goodtrack[] = FormHelper::validate_time_field_not_empty($myvalues, 'datedesired_timeonly', 'Desired Time');
            
            $goodtrack[] = FormHelper::validate_date_field_not_empty($myvalues, 'preopdate_dateonly', 'Preop Date');
            $goodtrack[] = FormHelper::validate_time_field_not_empty($myvalues, 'preopdate_timeonly', 'Preop Time');
        } else
        if($currentstep == 3)
        {
            $goodtrack[] = FormHelper::validate_text_field_not_empty($myvalues, 'esig', 'Electronic Signature');
        }
        
        //Check for trouble
        foreach($goodtrack as $value)
        {
            if($value === FALSE)
            {
                //There was trouble.
                return FALSE;
            }
        }
        //There was no trouble, yay!
        return TRUE;
    }
    
    /**
     * Write the values into the database.
     * Return 0 if there was an error, else 1.
     */
    function updateDatabaseFromFormState($form, &$form_state)
    {
        $myvalues = $form_state['values'];
        
        //Get key information now for replacement logic.
        $userinfo = $this->m_oContext->getUserInfo();
        $nSiteID = $this->m_oContext->getSiteID();
        $nIEN = $myvalues['tid'];
        $orderFileIen = $myvalues['OrderFileIen'];
        $nUID = $this->m_oContext->getUID();
        $sCWFS = $this->m_oTT->getTicketWorkflowState($nSiteID . '-' . $nIEN);
        $updated_dt = date("Y-m-d H:i:s", time());
        
        $reasonCode = $myvalues['cancelreason'];
        $cancelesig = $myvalues['esig'];
        
        $mdwsDao = $this->m_oContext->getMdwsClient();
        $orderChecks = $form_state['orderchecks_result'];
        
        $args = array();
        $neworder = array();
        try
        {
            $args['patientId'] = $myvalues['PatientID'];
            $args['locationIEN'] = $myvalues['neworderlocation'];
            $args['imagingTypeId'] = $myvalues['neworderimagetype'];
            $args['orderableItemId'] = $myvalues['neworderitem'];
            $args['urgencyCode'] = $myvalues['neworderurgency'];
            $args['modeCode'] = $myvalues['modecode'];
            $args['classCode'] = $myvalues['category'];
            $args['submitTo'] = $myvalues['submitto'];
            $args['pregnant'] = $myvalues['pregnant'];
            $args['isolation'] = $myvalues['isolation'];
            $args['reasonForStudy'] = $myvalues['reasonforstudy'];
            $clinhistArray = explode("\n",$myvalues['clinhist']);
            $args['clinicalHx'] = $clinhistArray;
            $datetimedesired = $myvalues['datedesired_dateonly'].' '.$myvalues['datedesired_timeonly'];
            $args['startDateTime'] = strtotime($datetimedesired);
            $preopdatetime = $myvalues['preopdate_dateonly'].' '.$myvalues['preopdate_timeonly'];
            $args['preOpDateTime'] = strtotime($preopdatetime);
            if(!isset($myvalues['newordermodifiers']))
            {
                $args['modifierIds'] = array();
            } else {
                $mids = array();
                foreach($myvalues['newordermodifiers'] as $k=>$v)
                {
                    if($k==$v)
                    {
                        if($v == 'NONE')
                        {
                            //We just want an empty array then.
                            $mids = array();
                            break;
                        }
                        $mids[] = $k;   //The value is the key
                    }
                }
                $args['modifierIds'] = $mids;
            }
            $args['eSig'] = $myvalues['esig'];

            error_log('DEBUG NEW ORDER orderChecks='.print_r($orderChecks,TRUE));
            error_log('DEBUG NEW ORDER args='.print_r($args,TRUE));

            $neworder = MdwsNewOrderUtils::createNewRadiologyOrder($mdwsDao, $orderChecks, $args);
            $neworder['replaced_tid'] = $myvalues['tid'];
            $form_state['finalstep_result'] = $neworder;
            //$order['radiologyOrderId']
            //drupal_set_message('Replaced '.$myvalues['tid'].' with '.$neworder['radiologyOrderId']);

        } catch (\Exception $ex) {
            /*
            drupal_set_message('Failed to create replacement of '
                    .$nIEN.' because '.$ex->getMessage(),'error');
             */
            throw $ex;
        }
        
        
    //return TRUE;

        //Now cancel the old order.
        try
        {
            $results = MdwsUtils::cancelRadiologyOrder($mdwsDao, 
                    $myvalues['PatientID'],
                    $orderFileIen,
                    $mdwsDao->getDUZ(),
                    'FakeLocation',
                    $reasonCode, 
                    $cancelesig);
            $cancelled_iens = $results['cancelled_iens'];
            $failed_iens = $results['failed_iens'];
        } catch (\Exception $ex) {
            drupal_set_message('Failed to cancel '
                    .$nIEN.' on replace because '.$ex->getMessage(),'error');
            throw $ex;
        }
        
        $sNewWFS = 'IA';
        $this->m_oTT->setTicketWorkflowState($nSiteID . '-' . $nIEN, $nUID, $sNewWFS, $sCWFS, $updated_dt);

        //Write success message
        drupal_set_message('Replaced Order ' . $myvalues['tid'] 
                . ' (' . $myvalues['procName'] .') with '
                .$neworder['radiologyOrderId']);
        
        
        return TRUE;
    }
    
    public static function getStepCount()
    {
        return 3;
    }

    /**
     * Return a code as follows...
     * b = navigate back
     * n = navigate to next
     * f = finish processing
     * NULL = no workflow change
     */
    public static function getWorkflowAction($form_state)
    {
        if(isset($form_state['values']))
        {
            $myvalues = $form_state['values'];
        } else {
            $myvalues = array();
        }
        if(isset($myvalues['navigationoverride']) && $myvalues['navigationoverride'] > '')
        {
            //Allow workflow action to be overridden by value in the field
            $clickedvalue = strtolower($myvalues['navigationoverride']);
            $clickednext = strpos($clickedvalue,'next') !== FALSE;
            $clickedback = strpos($clickedvalue,'back') !== FALSE;
            $clickedfinish = strpos($clickedvalue,'finish') !== FALSE;
        } else {
            //Workflow action is interpretted from the button clicked
            if(isset($form_state['clicked_button']))
            {
                $clickedbutton = $form_state['clicked_button'];
                $clickedvalue = strtolower($clickedbutton['#value']);
                $clickednext = strpos($clickedvalue,'next') !== FALSE;
                $clickedback = strpos($clickedvalue,'back') !== FALSE;
                $clickedfinish = strpos($clickedvalue,'finish') !== FALSE;
            } else {
                $clickedbutton = NULL;
                $clickedvalue = NULL;
                $clickednext = FALSE;
                $clickedback = FALSE;
                $clickedfinish = FALSE;
            }
        }
        if($clickedback)
        {
            return 'b';
        } else
        if($clickednext)
        {
            return 'n';
        } else
        if($clickedfinish)
        {
            return 'f';
        }
        return NULL;
    }
    
    /**
     * Just tell us what step was submitted, not what step we are now on.
     */
    public function getSubmittedStepNumber($form_state)
    {
        if(isset($form_state['values'])) 
        {
            $currentstep = $form_state['step'];
        } else {
            $currentstep = 0;
        }    
        return $currentstep;
    }
    
    private function getNonEmptyValueFromArrayElseAlternateArray($a1, $k1, $a2, $k2)
    {
        return empty($a1[$k1]) ? $a2[$k2] : $a1[$k1];
    }
    
    private function getNonEmptyValueFromArrayElseAlternateLiteral($a1, $k1, $literal)
    {
        return empty($a1[$k1]) ? $literal : $a1[$k1];
    }
    
    /**
     * Get the markup of the form
     */
    public function getForm($form, &$form_state, $disabled, $myvalues)
    {
        $actioncode = $this->getWorkflowAction($form_state);
        $clickednext = $actioncode == 'n';
        $clickedback = $actioncode == 'b';
        $clickedfinish = $actioncode == 'f';
    
        if(isset($form_state['values'])) 
        {
            if($clickednext || $clickedfinish)
            {
                $move = 1;
            } else if($clickedback) {
                $move = -1;
            } else {
                $move = 0;
            }
            $currentstep = $form_state['step'] + $move;
        } else {
            //When no values were already posted then 
            //we can be sure we are step one
            $currentstep = 1;
        }    
        if($currentstep < 1)
        {
            throw new \Exception('Cannot have a step = '.$currentstep);
        } else if($currentstep > $this->getStepCount()){
            //We can be here if the submit on the final step 
            //failed and we are repeating the last step after submit
            $currentstep = $this->getStepCount();   //Repeat last step
        }
        $form_state['step'] = $currentstep;
        
        //Set flags to adjust UI for steps already been completed
        $disabled_step1 = $disabled || ($currentstep > 1);
        $disabled_step2 = $disabled || ($currentstep > 2);
        
        
        //Hidden values in the form
        $form['hiddenthings']['navigationoverride'] = array(
            '#type'       => 'hidden',
            '#attributes' =>array('id'=> 'replaceorderstep'),
            '#default_value' => '',
        );
        $form['hiddenthings']['tid'] = array('#type' => 'hidden', '#value' => $myvalues['tid']);
        $form['hiddenthings']['procName'] = array('#type' => 'hidden', '#value' => $myvalues['procName']);
        $form['hiddenthings']['OrderFileIen'] = array('#type' => 'hidden', '#value' => $myvalues['OrderFileIen']);
        $form['hiddenthings']['PatientID'] = array('#type' => 'hidden', '#value' => $myvalues['PatientID']);
        $form['hiddenthings']['currentstep'] = array('#type' => 'hidden', '#value' => $currentstep);
        if($currentstep != 1)
        {
            $form['hiddenthings']['cancelreason'] = array('#type' => 'hidden', '#value' => $myvalues['cancelreason']);
            if($myvalues['neworderimagetype'] != NULL)
            {
                $form['hiddenthings']['neworderimagetype'] = array('#type' => 'hidden', '#value' => $myvalues['neworderimagetype']);
            }
        }
        if($currentstep != 2)
        {
            if($myvalues['neworderlocation'] != NULL)
            {
                $form['hiddenthings']['neworderlocation'] = array('#type' => 'hidden', '#value' => $myvalues['neworderlocation']);
            }
            if($myvalues['neworderitem'] != NULL)
            {
                $form['hiddenthings']['neworderitem'] = array('#type' => 'hidden', '#value' => $myvalues['neworderitem']);
            }
            if($myvalues['neworderurgency'] != NULL)
            {
                $form['hiddenthings']['neworderurgency'] = array('#type' => 'hidden', '#value' => $myvalues['neworderurgency']);
            }
            if($myvalues['modecode'] != NULL)
            {
                $form['hiddenthings']['modecode'] = array('#type' => 'hidden', '#value' => $myvalues['modecode']);
            }
            if($myvalues['category'] != NULL)
            {
                $form['hiddenthings']['category'] = array('#type' => 'hidden', '#value' => $myvalues['category']);
            }
            if($myvalues['submitto'] != NULL)
            {
                $form['hiddenthings']['submitto'] = array('#type' => 'hidden', '#value' => $myvalues['submitto']);
            }
            $form['hiddenthings']['isolation'] = array('#type' => 'hidden', '#value' => $myvalues['isolation']);
            $form['hiddenthings']['pregnant'] = array('#type' => 'hidden', '#value' => $myvalues['pregnant']);
            if($myvalues['reasonforstudy'] != NULL)
            {
                $form['hiddenthings']['reasonforstudy'] = array('#type' => 'hidden', '#value' => $myvalues['reasonforstudy']);
            }
            if($myvalues['clinhist'] != NULL)
            {
                $form['hiddenthings']['clinhist'] = array('#type' => 'hidden', '#value' => $myvalues['clinhist']);
            }
            $form['hiddenthings']['datedesired_dateonly'] = array('#type' => 'hidden', '#value' => $myvalues['datedesired_dateonly']);
            $form['hiddenthings']['preopdate_dateonly'] = array('#type' => 'hidden', '#value' => $myvalues['preopdate_dateonly']);
            $form['hiddenthings']['datedesired_timeonly'] = array('#type' => 'hidden', '#value' => $myvalues['datedesired_timeonly']);
            $form['hiddenthings']['preopdate_timeonly'] = array('#type' => 'hidden', '#value' => $myvalues['preopdate_timeonly']);
        }
            
        $form['data_entry_area1'] = array(
            '#prefix' => "\n<section class='multistep-dataentry'>"
            . "<H2>Step $currentstep of {$this->getStepCount()}</H2>\n",
            '#suffix' => "\n</section>\n",
            '#disabled' => $disabled,
        );

        //$testdate = date('Ymd.Hi', date("Y-m-d H:i:s"));

        $oDD = new \raptor\DashboardData($this->m_oContext);
        $rpd = $oDD->getDashboardDetails();
            
        $mdwsDao = $this->m_oContext->getMdwsClient();
        $aCancelOptions = MdwsUtils::getRadiologyCancellationReasons($mdwsDao);
        $form['data_entry_area1']['toppart']['cancelreason'] = array(
            "#type" => "select",
            "#title" => t('Replacement Reason'),
            "#options" => $aCancelOptions,
            "#description" => t("Select reason for canceling the existing order."),
            "#required" => TRUE,
            "#default_value" => $myvalues['cancelreason'],
            "#disabled" => $disabled_step1,
            );        
        
        $imagetypes = MdwsNewOrderUtils::getImagingTypes($mdwsDao);
        $neworderimagetype = FormHelper::getKeyOfValue($imagetypes, $rpd['ImageType']);
        if($neworderimagetype === FALSE)
        {
            $neworderimagetype = NULL;
        }
        $neworderimagetype = $this->getNonEmptyValueFromArrayElseAlternateLiteral($myvalues, 'neworderimagetype', $neworderimagetype);
        $form['data_entry_area1']['toppart']['neworderimagetype'] = array(
            "#type" => "select",
            "#title" => t('Imaging Type'),
            "#options" => $imagetypes,
            "#description" => t("Select Imaging Type for the new order."),
            "#default_value" => $neworderimagetype,
            "#required" => TRUE,
            "#disabled" => $disabled_step1,
            );
        
        if($currentstep > 1)
        {
            //Important NOT to mark fields as #required else BACK will fail!!!
            $imagingTypeId = intval($myvalues['neworderimagetype']);
            $locations = MdwsUtils::getHospitalLocations($mdwsDao);
            $neworderlocation = FormHelper::getKeyOfValue($locations, $rpd['PatientLocation']);
            if($neworderlocation === FALSE)
            {
                $neworderlocation = NULL;
            }
            $neworderlocation = $this->getNonEmptyValueFromArrayElseAlternateLiteral($myvalues, 'neworderlocation', $neworderlocation);
            $form['data_entry_area1']['toppart']['neworderlocation'] = array(
                "#type" => "select",
                "#empty_option"=>t('- Select -'),
                "#title" => FormHelper::getTitleAsRequiredField('Location'),
                "#options" => $locations,
                "#description" => t("Select location"),
                "#default_value" => $neworderlocation,
                "#disabled" => $disabled_step2,
                );        
                
            $raw_orderitems = MdwsNewOrderUtils::getOrderableItems($mdwsDao, $imagingTypeId);
            $orderitems_options = array();
            foreach($raw_orderitems as $k=>$v)
            {
                $orderitems_options[$k] = $v['name'];
            }
            $neworderitem = FormHelper::getKeyOfValue($orderitems_options, $rpd['Procedure']);
            if($neworderitem === FALSE)
            {
                $neworderitem = NULL;
            }
            $neworderitem = $this->getNonEmptyValueFromArrayElseAlternateLiteral($myvalues, 'neworderitem', $neworderitem);
            $form['data_entry_area1']['toppart']['neworderitem'] = array(
                "#type" => "select",
                "#empty_option"=>t('- Select -'),
                "#title" => FormHelper::getTitleAsRequiredField("Orderable Item"),
                "#options" => $orderitems_options,
                "#description" => t("Select orderable item (imaging procedure)"),
                "#default_value" => $neworderitem,
                "#disabled" => $disabled_step2,
                );        

            $patientId = $myvalues['PatientID'];
            $raworderoptions = MdwsNewOrderUtils::getRadiologyOrderDialog($mdwsDao, $imagingTypeId, $patientId);
error_log("DEBUG LOOK getRadiologyOrderDialog...\n".print_r($raworderoptions,TRUE));

            $raw_modifiers = $raworderoptions['modifiers'];
            if(!is_array($raw_modifiers) || count($raw_modifiers) < 1)
            {
                $form['data_entry_area1']['toppart']['newordermodifiers'] = array(
                    "#type" => "checkboxes",
                    "#title" => t("Modifiers"),
                    "#options" => array('NONE'=>'None'),
                    "#default_value" => array('NONE'=>'NONE'),
                    "#disabled" => TRUE,
                    );        
            } else {
                $options_modifiers = array();
                foreach($raw_modifiers as $k=>$v)
                {
                    $options_modifiers[$k] = $v;
                }
                $form['data_entry_area1']['toppart']['newordermodifiers'] = array(
                    "#type" => "checkboxes",
                    "#title" => t("Modifiers"),
                    "#options" => $options_modifiers,
                    "#disabled" => $disabled_step2,
                    );        
            }

            $form['data_entry_area1']['toppart']['LB1'] = array(
                '#prefix' => "\n<div id='lb1' style='float:left; width: 250px; padding: 0px 0px 0px 0px'>\n",
                '#suffix' => "\n</div>\n",
            );
            
            $urgencies = $raworderoptions['urgencies'];
            $neworderurgency = FormHelper::getKeyOfValue($urgencies, $rpd['Urgency']);
            if($neworderurgency === FALSE)
            {
                $neworderurgency = NULL;
            }
            $neworderurgency = $this->getNonEmptyValueFromArrayElseAlternateLiteral($myvalues, 'neworderurgency', $neworderurgency);
            $form['data_entry_area1']['toppart']['LB1']['neworderurgency'] = array(
                "#type" => "select",
                "#empty_option"=>t('- Select -'),
                "#title" => FormHelper::getTitleAsRequiredField('Urgency'),
                "#options" => $urgencies,
                "#description" => t('Select urgency'),
                "#default_value" => $neworderurgency,
                "#disabled" => $disabled_step2,
                );        
            
            $transports = $raworderoptions['transports'];
            $modecode = FormHelper::getKeyOfValue($transports, $rpd['Transport']);
            if($modecode === FALSE)
            {
                $modecode = NULL;
            }
            $modecode = $this->getNonEmptyValueFromArrayElseAlternateLiteral($myvalues, 'modecode', $modecode);
            $form['data_entry_area1']['toppart']['LB1']['modecode'] = array(
                "#type" => "select",
                "#empty_option"=>t('- Select -'),
                "#title" => FormHelper::getTitleAsRequiredField("Transports"),
                "#options" => $transports,
                "#description" => t("Select mode code"),
                "#default_value" => $modecode,
                "#disabled" => $disabled_step2,
                );        

            $form['data_entry_area1']['toppart']['RB1'] = array(
                '#prefix' => "\n<div id='rb1'>\n",
                '#suffix' => "\n</div>\n",
            );
            
            $categories = $raworderoptions['categories'];
            $category = FormHelper::getKeyOfValue($categories, $rpd['ExamCategory']);
            if($category === FALSE)
            {
                $category = NULL;
            }
            $category = $this->getNonEmptyValueFromArrayElseAlternateLiteral($myvalues, 'category', $category);
            $form['data_entry_area1']['toppart']['RB1']['category'] = array(
                "#type" => "select",
                "#empty_option"=>t('- Select -'),
                "#title" => FormHelper::getTitleAsRequiredField("Category"),
                "#options" => $categories,
                "#description" => t('Select class code'),
                "#default_value" => $category,
                "#disabled" => $disabled_step2,
                );        

            $options_submitTo = $raworderoptions['submitTo'];
            $findval_submitto = isset($rpd['LocationTx']) ? $rpd['LocationTx'] : '';
            $submitto = FormHelper::getKeyOfValue($options_submitTo, $findval_submitto);
            if($submitto === FALSE)
            {
                $submitto = NULL;
            }
            $submitto = $this->getNonEmptyValueFromArrayElseAlternateLiteral($myvalues, 'submitto', $submitto);
            $form['data_entry_area1']['toppart']['RB1']['submitto'] = array(
                "#type" => "select",
                "#empty_option"=>t('- Select -'),
                "#title" => FormHelper::getTitleAsRequiredField("Submit To"),
                "#options" => $options_submitTo,
                "#description" => t('Select the facility for this order'),
                "#default_value" => $submitto,
                "#disabled" => $disabled_step2,
                );        

            $form['data_entry_area1']['toppart']['LB2'] = array(
                '#prefix' => "\n<div id='lb2' style='float:left; width: 250px; padding: 0px 0px 0px 0px'>\n",
                '#suffix' => "\n</div>\n",
            );
            
            $form['data_entry_area1']['toppart']['LB2']['isolation'] = array(
                "#type" => "radios",
                "#empty_option"=>t('- Select -'),
                "#title" => FormHelper::getTitleAsRequiredField("Isolation"),
                "#options" => array(1=>t('Yes'),2=>t('No'),3=>t('Unknown')),
                "#default_value" => $myvalues['isolation'],
                "#disabled" => $disabled_step2,
                );        
            
            $form['data_entry_area1']['toppart']['RB2'] = array(
                '#prefix' => "\n<div id='rb2'>\n",
                '#suffix' => "\n</div>\n",
            );

            $form['data_entry_area1']['toppart']['RB2']['pregnant'] = array(
                "#type" => "radios",
                "#title" => FormHelper::getTitleAsRequiredField("Pregnant"),
                "#options" => array(1=>t('Yes'),2=>t('No'),3=>t('Unknown')),
                "#default_value" => $myvalues['pregnant'],
                "#disabled" => $disabled_step2,
                );        

            $reasonforstudy = $this->getNonEmptyValueFromArrayElseAlternateArray($myvalues, 'reasonforstudy', $rpd, 'ReasonForStudy');
            $form['data_entry_area1']['toppart']['reasonforstudy'] = array(
                '#type'          => 'textfield',
                '#title'         => FormHelper::getTitleAsRequiredField('Reason for Study'),
                '#size' => 64, 
                '#maxlength' => 64, 
                "#description" => t('Provide short reason for study.  (64 characters maximum)'),
                "#default_value" => $reasonforstudy,
                "#disabled" => $disabled_step2,
            );

            
            $clinhist = $this->getNonEmptyValueFromArrayElseAlternateArray($myvalues, 'clinhist', $rpd, 'ClinicalHistory');
            $form['data_entry_area1']['toppart']['clinhist'] = array(
                '#type'          => 'textarea',
                '#title'         => t('Clinical History'),
                "#disabled" => $disabled_step2,
                "#default_value" => $clinhist,
            );

            
            $form['data_entry_area1']['toppart']['LB3'] = array(
                '#prefix' => "\n<div id='lb3' style='float:left; padding: 0px 30px 0px 0px'>\n",
                '#suffix' => "\n</div>\n",
            );
            
            
            if(isset($myvalues['datedesired_dateonly']))
            {
                $datedesired_dateonly = $myvalues['datedesired_dateonly'];
            } else {
                $datedesired_dateonly = NULL;
            }
            $form['data_entry_area1']['toppart']['LB3']['datedesired_dateonly'] = array(
                '#type' => 'textfield',
                '#attributes' =>array('id'=> 'edit-datedesired-dateonly'
                                     ,'class' => array('datepicker','hasDatepicker')
                        ),
                '#size' => 10, 
                '#maxlength' => 10, 
                '#title'     => FormHelper::getTitleAsRequiredField('Date Desired'),
                "#disabled" => $disabled_step2,
                "#default_value" => $datedesired_dateonly,
                "#description" => t('When would you like this procedure to occur? (MM/DD/YYYY)'),
            );

            if(isset($myvalues['datedesired_timeonly']))
            {
                $datedesired_timeonly = $myvalues['datedesired_timeonly'];
            } else {
                $datedesired_timeonly = NULL;
            }
            $form['data_entry_area1']['toppart']['LB3']['datedesired_timeonly'] = array(
                '#type' => 'textfield',
                '#attributes' =>array('id'=> 'edit-datedesired-timeonly'
                                     ,'class' => array('ui-timepicker-input','hasTimepicker')
                        ),
                '#size' => 5, 
                '#maxlength' => 5, 
                '#title'     => FormHelper::getTitleAsRequiredField('Desired Exam Time'),
                "#disabled" => $disabled_step2,
                "#default_value" => $datedesired_timeonly,
                "#description" => t('When would you like for this procedure to occur? (HH:MM military time)'),
            );
            
            $form['data_entry_area1']['toppart']['RB3'] = array(
                '#prefix' => "\n<div id='rb3'>\n",
                '#suffix' => "\n</div>\n",
            );
            
            if(isset($myvalues['preopdate_dateonly']))
            {
                $preopdate_dateonly = $myvalues['preopdate_dateonly'];
            } else {
                $preopdate_dateonly = NULL;
            }
            $form['data_entry_area1']['toppart']['RB3']['preopdate_dateonly'] = array(
                '#type'          => 'textfield',
                '#attributes' =>array('id'=> 'edit-preopdate-dateonly'
                                     ,'class' => array('datepicker','hasDatepicker')
                        ),
                '#size' => 10, 
                '#maxlength' => 10, 
                '#title'         => FormHelper::getTitleAsRequiredField('PreOp Scheduled'),
                "#disabled" => $disabled_step2,
                "#default_value" => $preopdate_dateonly,
                "#description" => t('What is the preop date? (MM/DD/YYYY)'),
            );

            if(isset($myvalues['preopdate_timeonly']))
            {
                $preopdate_timeonly = $myvalues['preopdate_timeonly'];
            } else {
                $preopdate_timeonly = NULL;
            }
            $form['data_entry_area1']['toppart']['RB3']['preopdate_timeonly'] = array(
                '#type' => 'textfield',
                '#attributes' =>array('id'=> 'edit-preopdate-timeonly'
                                     ,'class' => array('ui-timepicker-input','hasTimepicker')
                        ),
                '#size' => 5, 
                '#maxlength' => 5, 
                '#title'     => FormHelper::getTitleAsRequiredField('Preop Time'),
                "#disabled" => $disabled_step2,
                "#default_value" => $preopdate_timeonly,
                "#description" => t('What is the preop start time? (HH:MM military time)'),
            );
            
            if($currentstep == $this->getStepCount())
            {
                //Final step
                $args = array();
                $args['patientId'] = $myvalues['PatientID'];
                
                $date = new \DateTime();
                $timestamp = $date->getTimestamp(); 
                
                $startdatetime = strtotime($myvalues['datedesired_dateonly'] . ' ' . $myvalues['datedesired_timeonly']);
                $args['startDateTime'] = $startdatetime;   //$timestamp;// //Ymd.Hi TODO $myvalues['datedesired'];
                
                $args['locationIEN'] = $myvalues['neworderlocation'];
                $args['orderableItemId'] = $myvalues['neworderitem'];
                $rawchecks = MdwsNewOrderUtils::getRadiologyOrderChecks($mdwsDao, $args);
                $form_state['orderchecks_result'] = $rawchecks;
                
                //die('LOOKNOW>>>>'.print_r($rawchecks,TRUE));
                
                $checkresultitems = array();
                foreach($rawchecks as $key=>$value)
                {
                    $checkresultitems[$key] = $value['name'];
                }
                $checkresulthtml = implode('<li>',$checkresultitems);
                $form['data_entry_area1']['toppart']['confirmationinfo'] = array(
                    '#prefix' => "\n<section class='generic-warning-area'>\n"
                    . '<p><ol>'
                    . $checkresulthtml
                    . '</ol></p>',
                    '#suffix' => "\n</section>\n",
                    '#disabled' => $disabled,
                );
                
                $form['data_entry_area1']['toppart']['esig'] = array(
                    '#type'          => 'password',
                    '#title'         => FormHelper::getTitleAsRequiredField('Electronic Signature'),
                    '#disabled'      => $disabled,
                    '#size' => 55, 
                    '#maxlength' => 128, 
                    '#default_value' => '',
                    //'#required' => TRUE,
                );
            }
        }
         
       
        $form['data_entry_area1']['action_buttons'] = array(
            '#prefix' => "\n<section class='raptor-action-buttons'>\n",
            '#suffix' => "\n</section>\n",
            '#disabled' => $disabled,
        );

        if($currentstep > 1)
        {
            $form['data_entry_area1']['action_buttons']['back'] = array('#type' => 'submit'
                    ,'#id' => 'replace-order-submit-back-button' //alex edits
                    , '#attributes' => array('class' => array('admin-action-button'))
                    , '#value' => t('<< Back')
                    //, '#limit_validation_errors' => array()
                    , '#disabled' => $disabled
            );
        }
        
        if($currentstep == $this->getStepCount())
        {
            $form['data_entry_area1']['action_buttons']['next'] = array('#type' => 'submit'
                    ,'#id' => 'replace-order-submit-next-button' //alex edits
                    , '#attributes' => array('class' => array('admin-action-button'))
                    , '#value' => t('Finish >>')
                    , '#disabled' => $disabled
            );
        } else {
            $form['data_entry_area1']['action_buttons']['next'] = array('#type' => 'submit'
                    ,'#id' => 'replace-order-submit-next-button' //alex edits
                    , '#attributes' => array('class' => array('admin-action-button'))
                    , '#value' => t('Next >>')
                    , '#disabled' => $disabled
            );
        }
        
        
        
        $form['data_entry_area1']['action_buttons']['cancel'] = array('#type' => 'item'
                , '#markup' => '<input class="raptor-dialog-cancel" type="button" value="Exit with No Changes">');
 
        
        return $form;
    }
}


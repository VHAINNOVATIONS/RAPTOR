<?php
/**
 * @file
 * ------------------------------------------------------------------------------------
 * Created by SAN Business Consultants for RAPTOR phase 2
 * Open Source VA Innovation Project 2011-2014
 * VA Innovator: Dr. Jonathan Medverd
 * SAN Implementation: Andrew Casertano, Frank Font, et al
 * Contacts: acasertano@sanbusinessconsultants.com, ffont@sanbusinessconsultants.com
 * ------------------------------------------------------------------------------------
 *  
 */

namespace raptor_formulas;

/**
 * Logic for scoring order match
 *
 * @author Frank Font of SAN Business Consultants
 */
class MatchOrderToProtocol 
{
    /**
     * The original order should already be analyzed into clues map
     * @param type $cluesmap map of clues
     * @param type $psn protocol short name
     * @param type $longname
     * @param type $modality_abbr
     * @param type $contrast_yn
     * @param type $kwmap map of keywords for each protocol shortname
     * @return score
     */
    public function getProtocolMatchScore($cluesmap
        , $psn, $longname, $modality_abbr, $contrast_yn
            , $kwmap)
    {
        $matchscore = 0;
        if($modality_abbr == $cluesmap['modality_abbr'])
        {
            $matchscore++;
        }
        if($matchscore > 0 || trim($cluesmap['modality_abbr']) == '' )
        {
            //Do not add to score if contrast setting is not compatible
            if($cluesmap['contrast'] === NULL || $contrast_yn === NULL 
                    || ($contrast_yn == 1 && $cluesmap['contrast'] === TRUE)
                    || ($contrast_yn == 0 && $cluesmap['contrast'] === FALSE))
            {
                $matchscore++;  //Give it one more just because we got past the contrast filter.
                if(is_array($cluesmap['cpt_codes']))
                {
                    foreach($cluesmap['cpt_codes'] as $cptcode)
                    {
                        //TODO -- give score updates for CPT code matches
                    }
                }
                if(isset($kwmap[$psn]))
                {
                    //We have keywords, so factor them in
                    foreach($kwmap[$psn] as $wg=>$kwg)
                    {
                        $matches = $this->countMatchingWords($kwg, $cluesmap['keywords']);
                        $matchscore += (5 - $wg) * $matches;
                    }
                } else {
                    //Use the protocol library long name as a clue (not as good as real keywords)
                    $tempkw = $this->getOrderPhraseKeywords(strtoupper($longname));
                    $matches = $this->countMatchingWords($tempkw, $cluesmap['keywords']);
                }
                if($matches > 0)
                {
                    $matchscore += ($matches + 1);    //MUST add one more!!!
                }
            }
        }
        return $matchscore;
    }
}

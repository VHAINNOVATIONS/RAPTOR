<?php
/**
 * @file
 * Plain (naked) layout template, simply printing the content area.
 */
print $content['content'];
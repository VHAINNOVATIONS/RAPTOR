// Provide reference to Drupal jQuery library
var DrupaljQuery = jQuery;
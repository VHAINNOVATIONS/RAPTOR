var egfrs = [ //this is the sample data for egfrs
	{
		date: "03-16-2014",
		egfr: 50
	},
	{
		date: "03-17-2014",
		egfr: 49
	},
	{
		date: "03-18-2014",
		egfr: 51,
		flag: "MISSING"
	},
	{
		date: "03-19-2014",
		egfr: 56
	},
	{
		date: "03-20-2014",
		egfr: 45
	},
	{
		date: "03-21-2014",
		egfr: 43,
		flag: "NOCIRCLE"
	},
	{
		date: "03-22-2014",
		egfr: 47
	},
	{
		date: "03-23-2014",
		egfr: 50
	}
];
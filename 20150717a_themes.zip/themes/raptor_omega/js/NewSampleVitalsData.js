var vitals = [ //this is the sample data for vitals
	{
		date: "03-26-2014",
		temperature: 98.6,
		pulse: 81
	},
	{
		date: "03-27-2014",
		temperature: 99.8,
		pulse: 83,
		tempFlag: "MISSING"
	},
	{
		date: "03-28-2014",
		temperature: 97.6,
		pulse: 82,
		pulseFlag: "MISSING",
		tempFlag: "NOCIRCLE"
	},
	{
		date: "03-29-2014",
		temperature: 101.,
		pulse: 84
	},
	{
		date: "03-30-2014",
		temperature: 98.6,
		pulse: 82,
		tempFlag: "NOCIRCLE"
	},
	{
		date: "03-31-2014",
		temperature: 101.6,
		pulse: 80
	}
];

var temperatures = [ //this is the sample data for temperatures
	{
		date: "03-16-2014",
		temperature: 98.6
	},
	{
		date: "03-17-2014",
		temperature: 99.8,
		flag: "MISSING"
	},
	{
		date: "03-18-2014",
		temperature: 97.6
	},
	{
		date: "03-19-2014",
		temperature: 101.2
	},
	{
		date: "03-20-2014",
		temperature: 98.6
	},
	{
		date: "03-21-2014",
		temperature: 103.4,
		flag: "NOCIRCLE"
	},
	{
		date: "03-22-2014",
		temperature: 102.1
	},
	{
		date: "03-23-2014",
		temperature: 99.6
	}
];
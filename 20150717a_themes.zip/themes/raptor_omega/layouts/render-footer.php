<footer>
VA systems are intended to be used by authorized VA network users for view and retrieving information only except as otherwise explicitly authorized for official business and limited personal use under VA policy.  Information from this system resides on and transmits through computer systems and networks funded by the VA.
</footer>

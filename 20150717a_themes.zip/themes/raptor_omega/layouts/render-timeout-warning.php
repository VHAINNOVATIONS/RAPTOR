<div id="timeout-warning">
    You will be logged out in <span id="timeout-warning-time-left"></span> seconds 
    <button type="button" id="timeout-stay-signed-in">Yes, keep me signed in</button> 
    <button type="button" id="timeout-sign-me-out">No, sign me out</button>
</div>
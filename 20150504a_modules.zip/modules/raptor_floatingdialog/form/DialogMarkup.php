<?php
/**
 * ------------------------------------------------------------------------------------
 * Created by SAN Business Consultants for RAPTOR phase 2
 * Open Source VA Innovation Project 2011-2015
 * VA Innovator: Dr. Jonathan Medverd
 * SAN Implementation: Andrew Casertano, Frank Font, et al
 * Contacts: acasertano@sanbusinessconsultants.com, ffont@sanbusinessconsultants.com
 * ------------------------------------------------------------------------------------
 * 
 */

namespace raptor_floatingdialog;

/**
 * Implements the schedule ticket page.
 *
 * @author Frank Font of SAN Business Consultants
 */
class DialogMarkup
{

    function __construct()
    {
    }

    /**
     * Return the wrapper markup for the dialog
     */
    function getDialogWrapper()
    {
        $markup = "<h1>TODO</h1>";
        return $markup;
    }
}
DROP PROCEDURE IF EXISTS raptor_example_sp;




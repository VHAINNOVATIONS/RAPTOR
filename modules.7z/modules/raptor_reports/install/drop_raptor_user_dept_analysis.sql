DROP PROCEDURE IF EXISTS raptor_user_dept_analysis;




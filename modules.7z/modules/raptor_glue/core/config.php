<?php

//require_once '32bitVM_local_oldMDWS.inc';
//require_once '32bitVM_local_newMDWS.inc';
//require_once '64bitVM_SETUP203-4.inc';
//require_once '64bitVM_SETUP203-5.inc';
//require_once '64bitVA_146.inc';
//require_once '64bitVA_147.inc';
//require_once '64bitVM_184.inc';
//require_once '64bitVM_54-193.inc';
require_once '64bitVM_local.inc';

defined("RAPTOR_BUILD_ID")
    or define("RAPTOR_BUILD_ID", 'Test Candidate 20150508.1');

require_once 'InternalDefs.inc';
require_once 'TimeDefs.inc';
require_once 'VistaDefs.inc';
require_once 'ErrorCodeDefs.inc';
require_once 'GeneralDefs.inc';
require_once 'WorkflowDefs.inc';
require_once 'MdwsDefs.inc';


<?php

defined("EWD_DEFS_VERSION_INFO")
    or define("EWD_DEFS_VERSION_INFO", '20150716.1');

/*
 * These are EWD specific settings
 */



